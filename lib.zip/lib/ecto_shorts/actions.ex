defmodule EctoShorts.Actions do
  @moduledoc """
  Provides a standardized api for interacting with Ecto Schemas.

  `EctoShorts.Actions` is the main API for performing schema operations
  such as creating, updating, querying, deleting, and batching records.
  It abstracts common patterns and reduces boilerplate by enabling
  declarative, parameter-based input.

  ## Overview

  This module acts as a drop-in replacement for direct `Ecto.Repo` usage,
  enabling you to work directly with maps for data-driven workflows.
  It is built on top of a dynamic query expression builder api in the
  `EctoShorts` ecosystem.

  You can define a context module that wraps calls to this API:

      defmodule MyApp.Accounts do
        alias EctoShorts.Actions
        alias MyApp.Accounts.User

        def all_users(params), do: Actions.all(User, params, repo: MyApp.Repo)
        def create_user(params), do: Actions.create(User, params, repo: MyApp.Repo)
      end

  ## Query Filters

  This api takes a data-driven approach to filtering that emphasizes
  clarity and composability. Instead of manually constructing filtering
  logic, you can describe filters using simple maps or keyword lists.

  Each key-value pair in a parameter map describes a filter condition.
  Nested maps represent filters on associations or embedded structures.
  Specialized operations like `ilike`, range filters, or inclusion checks
  are expressed through declarative expressions:

    * `%{title: "Post"}` — Matches records where the `title` field equals "Post".
    * `%{title: %{ilike: "post"}}` — Performs a case-insensitive substring match on `title`.
    * `%{comments: %{body: %{ilike: "example"}}}` — Joins the `comments` association and filters `body` fields using `ilike`.
    * `%{inserted_at: %{gt: ~N[2023-01-01 00:00:00]}}` — Filters records with `inserted_at` after the specified datetime.

  This style of composition makes it easy to:

    * Reduce boilerplate by avoiding direct query syntax
    * Dynamically apply filters based on user input or runtime state
    * Extend functionality with minimal code changes
    * Support deeply nested filter logic in a consistent, readable format

  For example:

      EctoShorts.Actions.all(Post, %{id: 1, comments: %{body: %{ilike: "hello"}}})

  Would result in:

      from p in Post,
        where: p.id == 1,
        join: c in assoc(p, :comments),
        where: ilike(c.body, "%hello%")

  This behavior is powered by `EctoShorts.CommonFilters`, which turns
  deeply nested parameter maps into composable Ecto queries.

  See `EctoShorts.CommonFilters` for more.

  ## Shared Options

  The following options are supported across nearly all public functions:

    * `:repo` – Ecto.Repo used for writes

    * `:replica` – Ecto.Repo used for reads (preferred for read-only operations)
  """

  alias EctoShorts.{
    Actions.Error,
    CommonFilters,
    CommonParams,
    CommonSchemas,
    Config,
    CommonQueries,
    SchemaIntrospection,
    Utils
  }

  @type source :: binary()
  @type query :: Ecto.Query.t()
  @type queryable :: Ecto.Queryable.t()
  @type source_queryable :: {source(), queryable()}
  @type changeset :: Ecto.Changeset.t()
  @type schema_data :: Ecto.Schema.t()
  @type aggregate_options :: :avg | :count | :max | :min | :sum
  @type multi :: Ecto.Multi.t()
  @type multi_failure :: Ecto.Multi.failure()
  @type id :: integer() | binary()
  @type field :: atom()
  @type batch_key :: atom()
  @type batch_id :: map()
  @type params :: map()
  @type opts :: keyword()
  @type stream :: %Stream{}

  def preload(structs_or_struct_or_nil, preloads, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    Config.replica!(opts).preload(structs_or_struct_or_nil, preloads, opts)
  end

  @doc group: "Batch API"
  @doc since: "2.5.0"
  @doc """
  Fetches existing records in bulk for later use.

  The `batch_preload/4` function is used to prepare data for operations
  like `insert_all/3` by preloading existing records in bulk. This is
  especially helpful when you're trying to update or upsert records based
  on incoming parameters, and the changeset logic depends on having the
  current state of the record.

  Rather than performing one query per entry, this function batches all
  parameter sets into a single query using the provided `batch_key`.
  Each matching record is returned and merged back into the original
  input list as a `{existing_record, params}` tuple.

  ## How it works

  If a map in the input list contains enough keys to match a record
  (based on the given `batch_key`), the function will attempt to fetch
  that record from the database.

  The original input list is returned, with each map replaced by either:

    * A `{record, params}` tuple, if a matching record was found

    * The original map or tuple, if no match was found or the keys were
      insufficient.

  This format can be passed directly to `insert_all/3` and other bulk
  operations.

  ## Examples

      # Preloading by primary key:

      iex> EctoShorts.Actions.batch_preload(Post, :primary_key, [%{id: 1, title: "updated"}])
      [%{%Post{id: 1}, %{title: "updated"}}]

      # Preloading by custom keys:

      iex> EctoShorts.Actions.batch_preload(User, [:org_id, :email], [
      ...>   %{org_id: 1, email: "admin@example.com", name: "Admin"},
      ...>   %{org_id: 2, email: "editor@example.com", name: "Editor"}
      ...> ])
      [
        {%User{org_id: 1, email: "admin@example.com"}, %{name: "Admin"}},
        {%User{org_id: 2, email: "editor@example.com"}, %{name: "Editor"}}
      ]
  """
  @spec batch_preload(
          query() | queryable() | source_queryable(),
          batch_key(),
          list(params() | {params(), params()} | {schema_data(), params()})
        ) :: list(params() | {params(), params()} | {schema_data(), params()})
  @spec batch_preload(
          query() | queryable() | source_queryable(),
          batch_key(),
          list(params() | {params(), params()} | {schema_data(), params()}),
          opts()
        ) :: list(params() | {params(), params()} | {schema_data(), params()})
  def batch_preload(query, batch_key \\ :primary_key, params_list, opts \\ []) do
    case get_batch_params(params_list, batch_key, query) do
      [] ->
        params_list

      todo ->
        query
        |> batch(batch_key, todo, opts)
        |> put_batch_preload_results(params_list, batch_key, query)
    end
  end

  defp put_batch_preload_results(batch_results, params_list, batch_key, query) do
    Enum.map(params_list, fn
      {find_params, params} when is_map(find_params) and not is_struct(find_params) ->
        if has_batch_key?(find_params, batch_key, query) do
          case Map.get(batch_results, batch_id!(find_params, batch_key, query)) do
            nil -> {find_params, params}
            schema_data -> {schema_data, drop_batch_keys(params, batch_key, query)}
          end
        else
          params
        end

      params when is_map(params) and not is_struct(params) ->
        if has_batch_key?(params, batch_key, query) do
          case Map.get(batch_results, batch_id!(params, batch_key, query)) do
            nil -> params
            schema_data -> {schema_data, drop_batch_keys(params, batch_key, query)}
          end
        else
          params
        end

      term ->
        term
    end)
  end

  defp drop_batch_keys(params, batch_key, query) do
    case batch_key do
      :primary_key -> Map.drop(params, CommonSchemas.get_schema_reflection(query, :primary_key))
      keys -> Map.drop(params, keys)
    end
  end

  defp get_batch_params(params_list, batch_key, query) do
    Enum.reduce(params_list, [], fn
      {find_params, _params}, acc when is_map(find_params) and not is_struct(find_params) ->
        if has_batch_key?(find_params, batch_key, query) do
          [find_params | acc]
        else
          acc
        end

      params, acc when is_map(params) and not is_struct(params) ->
        if has_batch_key?(params, batch_key, query) do
          [params | acc]
        else
          acc
        end

      _, acc ->
        acc
    end)
  end

  @doc group: "Batch API"
  @doc """
  Finds multiple records in a single query using a list of search parameters.

  The `batch_find/4` function is a convenience wrapper around `batch/4` that
  returns just the matching records as a flat list. It’s useful when you want
  to look up multiple records without manually constructing `OR` queries or
  looping through results.

  Each map in the list of `params_list` is used to build a filter. All matching
  records are loaded in a single query, and returned in the order they matched
  the input parameters.

  If any entry does not match a record in the database, the entire operation
  will return an error. This ensures all entries are present and valid.

  For example, to find all users by their email addresses:

      iex> EctoShorts.Actions.batch_find(MyApp.User, [:email], [
      ...>   %{email: "jane@example.com"},
      ...>   %{email: "john@example.com"}
      ...> ])
      {:ok, [%User{email: "jane@example.com"}, %User{email: "john@example.com"}]}

  ## Batch key

  You can control which fields are used to match records by passing the `batch_key`
  argument. This can be a single key or a list of keys (composite key). If not provided,
  the schema’s primary key will be used by default.

      iex> EctoShorts.Actions.batch_find(MyApp.User, [:org_id, :email], [
      ...>   %{org_id: 1, email: "jane@example.com"},
      ...>   %{org_id: 2, email: "john@example.com"}
      ...> ])
      {:ok, [%User{org_id: 1}, %User{org_id: 2}]}

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options) for repo-related configuration.

  ## Examples

      iex> EctoShorts.Actions.batch_find(MyApp.User, [:email], [
      ...>   %{email: "jane@example.com"},
      ...>   %{email: "john@example.com"}
      ...> ])
      {:ok, [%User{email: "jane@example.com"}, %User{email: "john@example.com"}]}
  """
  @spec batch_find(
          query() | queryable() | source_queryable(),
          params_list :: list(params())
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec batch_find(
          query() | queryable() | source_queryable(),
          batch_key :: :primary_key | batch_key() | list(batch_key()),
          params_list :: list(params())
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec batch_find(
          query() | queryable() | source_queryable(),
          batch_key :: :primary_key | batch_key() | list(batch_key()),
          params_list :: list(params()),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def batch_find(query, batch_key \\ :primary_key, params_list, opts \\ []) do
    batch_results = batch(query, batch_key, params_list, opts)

    params_list
    |> Stream.with_index()
    |> Utils.reduce_all(fn {params, i} ->
      case Map.get(batch_results, batch_id!(params, batch_key, query)) do
        nil ->
          {:error,
           Error.call(:not_found, "Record not found.", %{
             query: query,
             params: params_list,
             failed_value: params,
             position: i,
             batch_key: normalize_batch_key(batch_key, query)
           })}

        schema_data ->
          {:ok, schema_data}
      end
    end)
  end

  @doc group: "Batch API"
  @doc """
  Performs a batched query and returns a map of results keyed by input parameters.

  Batching is a common technique used to reduce redundant queries by grouping
  similar fetch operations into a single database query. This is especially useful
  when handling many records at once, such as resolving fields in a GraphQL API
  or processing a list of identifiers in bulk.

  Instead of issuing one query per parameter set, this function combines all
  parameter sets into a single query and returns a result map that preserves
  the association between the original inputs and the fetched records.

      iex> EctoShorts.Actions.batch(Post, [:title], [
      ...>   %{title: "First Post"},
      ...>   %{title: "Second Post"}
      ...> ])

  Returns:

      %{
        %{title: "First Post"} => %Post{title: "First Post"},
        %{title: "Second Post"} => %Post{title: "Second Post"}
      }

  ## Composite keys

  You can specify a list of keys to match on using the `batch_key` argument:

      iex> EctoShorts.Actions.batch(User, [:org_id, :email], [
      ...>   %{org_id: 1, email: "admin@example.com"},
      ...>   %{org_id: 2, email: "editor@example.com"}
      ...> ])

  This ensures each input map is matched against all specified fields as a unique
  composite key.

  If no `batch_key` is provided, the schema's primary key is used automatically.
  If your schema does not define a primary key and no batch key is given,
  this function will raise an error.

  ## Examples

      iex> Actions.batch(Post, [:title], [%{title: "post_title"}])
      %{%{title: "post_title"} => %Post{title: "post_title"}}
  """
  @spec batch(
          query() | queryable() | source_queryable(),
          params_list :: list(params())
        ) :: %{batch_id() => schema_data()}
  @spec batch(
          query() | queryable() | source_queryable(),
          batch_key :: :primary_key | batch_key() | list(batch_key()),
          params_list :: list(params())
        ) :: %{batch_id() => schema_data()}
  @spec batch(
          query() | queryable() | source_queryable(),
          batch_key :: :primary_key | batch_key() | list(batch_key()),
          params_list :: list(params()),
          opts()
        ) :: %{batch_id() => schema_data()}
  def batch(query, batch_key \\ :primary_key, params_list, opts \\ []) do
    query
    |> all(%{or_where: params_list}, opts)
    |> Enum.group_by(&batch_id!(&1, batch_key, query))
    |> Map.new(fn
      {batch_id, []} ->
        {batch_id, []}

      {batch_id, [schema_data]} ->
        {batch_id, schema_data}

      {batch_id, schema_datas} ->
        raise "Expected one record for batch keys #{inspect(Map.keys(batch_id))}, got #{length(schema_datas)}"
    end)
  end

  defp batch_id!(data, primary_key_or_keys, query) do
    with :error <- batch_id(data, primary_key_or_keys, query) do
      raise "Batch key not found for schema #{CommonSchemas.get_schema_queryable(query)}: #{inspect(data)}"
    end
  end

  defp batch_id(data, primary_key_or_keys, query) do
    case normalize_batch_key(primary_key_or_keys, query) do
      [] -> :error
      keys -> fetch_keys(data, keys)
    end
  end

  defp has_batch_key?(data, value, query) do
    case fetch_keys(data, normalize_batch_key(value, query)) do
      :error -> false
      _ -> true
    end
  end

  defp fetch_keys(data, keys) do
    result =
      Utils.reduce_all(keys, fn key ->
        case Map.get(data, key) do
          nil -> {:error, key}
          value -> {:ok, {key, value}}
        end
      end)

    case result do
      {:ok, values} -> Map.new(values)
      _ -> :error
    end
  end

  defp normalize_batch_key(:primary_key, query) do
    CommonSchemas.get_schema_reflection(query, :primary_key)
  end

  defp normalize_batch_key(key, _query) do
    List.wrap(key)
  end

  @doc group: "Schema API"
  @doc since: "2.5.0"
  @doc """
  Inserts multiple records into the database.

  Each entry in the `params_list` is validated using the schema’s `changeset/2` function
  unless `validate: false` is passed.

  ## Conflict Handling

  If a complete primary key is present in a record, this function treats it as an upsert.
  It automatically applies:

    * `:conflict_target` set to the primary key
    * `:on_conflict` set to `{:replace, keys}` — where `keys` are all fields except the
      primary key and `:inserted_at`

  This allows partial updates on existing records during bulk inserts while skipping
  fields that cannot be nil.

  ## Preloading Existing Records

  Sometimes, you may need to preload existing records so that the changeset has access
  to required values:

    * If your changeset logic uses data from the existing row (e.g., to preserve an audit field).
    * If a required field cannot be overwritten by `nil`, and passing it directly would cause
      a constraint error.

  You can enable this behavior with the `:batch_preload` option:

      Actions.insert_all(User, params_list, batch_preload: :primary_key)

  This will call `batch_preload/4` and transform each param into
  `{existing_record, new_params}` tuples when a match is found.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  You can also pass any options accepted by [`Ecto.Repo.insert_all/3`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:insert_all/3).

  ## Examples

      iex> EctoShorts.Actions.insert_all(MyApp.User, [%{id: 1, name: "Jane"}], batch_preload: :primary_key)
      {:ok, {1, [%User{id: 1, name: "Jane"}]}}
  """
  @spec insert_all(
          query() | queryable() | source_queryable(),
          params_list :: list(any())
        ) :: {:ok, {non_neg_integer(), nil | [term()]}} | {:error, any()}
  @spec insert_all(
          query() | queryable() | source_queryable(),
          params_list :: list(any()),
          opts()
        ) :: {:ok, {non_neg_integer(), nil | [term()]}} | {:error, any()}
  def insert_all(query, params_list, opts \\ []) do
    schema_module = CommonSchemas.get_schema_queryable(query)

    with {:ok, inserts} <-
           CommonParams.convert_to_insert_all_params(
             schema_module,
             maybe_batch_preload(query, params_list, opts),
             opts
           ) do
      opts =
        if SchemaIntrospection.any_primary_key?(schema_module, inserts) do
          opts
          |> CommonParams.on_conflict_options(schema_module)
          |> Keyword.merge(opts)
        else
          opts
        end

      IO.inspect(inserts, label: "YOOO")

      {:ok, Config.repo!(opts).insert_all(schema_module, inserts, opts)}
    end
  end

  defp maybe_batch_preload(query, params_list, opts) do
    if Keyword.has_key?(opts, :batch_preload) do
      batch_preload(query, opts[:batch_preload] || :primary_key, params_list, opts)
    else
      params_list
    end
  end

  @doc group: "Schema API"
  @doc """
  Updates multiple records that match the given filter parameters.

  This function builds a query from the given schema or queryable, applies
  filters using the `find_params`, and performs a bulk update with the
  provided `update_params`.

  Unlike `update/4`, which works on a single struct or ID, this function
  updates all matching rows in one operation. This is useful when applying
  the same update across many records.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  You can also pass any options accepted by [`Ecto.Repo.update_all/3`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:update_all/3).

  ## Examples

      iex> EctoShorts.Actions.update_all(MyApp.User, %{active: false}, %{active: true})
      {5, nil}

      iex> EctoShorts.Actions.update_all(MyApp.User, %{role: "guest"}, %{role: "user"}, repo: MyApp.Repo)
      {12, nil}
  """
  @spec update_all(
          query() | queryable() | source_queryable(),
          params(),
          params()
        ) :: {non_neg_integer(), nil | [term()]}
  @spec update_all(
          query() | queryable() | source_queryable(),
          params(),
          params(),
          opts()
        ) :: {non_neg_integer(), nil | [term()]}
  def update_all(query, find_params, update_params, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    updates =
      query
      |> CommonSchemas.get_schema_queryable()
      |> CommonParams.convert_to_update_all_params(update_params, opts)

    query
    |> CommonFilters.convert_params_to_filter(find_params, opts)
    |> Config.repo!(opts).update_all(updates, opts)
  end

  @doc group: "Query API"
  @doc """
  Deletes all records that match the given filter parameters.

  This function builds a query from the provided schema or queryable,
  applies filters using the `params`, and removes all matching records
  from the database in a single operation.

  Unlike `delete/2`, which deletes one record at a time (by ID or struct),
  `delete_all/3` is more efficient for bulk deletions and does not call
  changesets or run validations.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  You can also pass any options accepted by
  [`Ecto.Repo.delete_all/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:delete_all/2).

  ## Examples

      iex> EctoShorts.Actions.delete_all(MyApp.User, %{active: false})
      {3, nil}

      iex> EctoShorts.Actions.delete_all(MyApp.Post, %{archived: true}, repo: MyApp.Repo)
      {7, nil}
  """
  @spec delete_all(
          query() | queryable() | source_queryable(),
          params()
        ) :: {non_neg_integer(), nil | [term()]}
  @spec delete_all(
          query() | queryable() | source_queryable(),
          params(),
          opts()
        ) :: {non_neg_integer(), nil | [term()]}
  def delete_all(query, params, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> CommonFilters.convert_params_to_filter(params, opts)
    |> Config.repo!(opts).delete_all(opts)
  end

  @doc group: "Multi API"
  @doc """
  Finds or creates many records sequentially inside a transaction.

  Each operation is executed one at a time in the order provided, using `Ecto.Multi`
  to wrap the logic in a single transaction. If any step fails (such as a validation
  error), the entire transaction is rolled back to ensure consistency.

  This function supports distinct parameters per operation. You can either:

    * Pass a single map to use as both the `find_params` and `create_params`, or
    * Pass a `{find_params, create_params}` tuple to look up a record with one set
      of values and create it with another if not found.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

    iex> params_list = [
    ...>   %{email: "user1@example.com", name: "User 1"},
    ...>   {%{email: "user2@example.com"}, %{email: "user2@example.com", name: "User 2"}}
    ...> ]
    ...> EctoShorts.Actions.find_or_create_many(MyApp.User, params_list)
    {:ok, [%User{}, %User{}]}
  """
  @spec find_or_create_many(
          query() | queryable() | source_queryable(),
          params_list :: list(map() | {map(), map()})
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec find_or_create_many(
          query() | queryable() | source_queryable(),
          params_list :: list(map() | {map(), map()}),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def find_or_create_many(query, params_list, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> multi_find_or_create(params_list, opts)
    |> Config.repo!(opts).transaction(opts)
    |> handle_multi_response()
  end

  defp multi_find_or_create(query, params_list, opts) do
    params_list
    |> Enum.with_index()
    |> Enum.reduce(Ecto.Multi.new(), fn {params, i}, multi ->
      Ecto.Multi.run(multi, {:find_or_create, i}, fn repo, _changes_so_far ->
        case query |> CommonFilters.convert_params_to_filter(params, opts) |> repo.one(opts) do
          nil ->
            with {:error, changeset} <-
                   query
                   |> create_changeset(params, opts)
                   |> repo.insert(opts) do
              {:error,
               {:conflict, "Failed to create record.",
                %{
                  query: query,
                  params: params_list,
                  changeset: changeset,
                  position: i,
                  keys: params
                }}}
            end

          schema_data ->
            {:ok, schema_data}
        end
      end)
    end)
  end

  @doc group: "Multi API"
  @doc since: "2.5.0"
  @doc """
  Finds and updates many records sequentially inside a transaction.

  Each step is performed one at a time, in order, using `Ecto.Multi` to wrap the
  entire operation in a single transaction. If any step fails (such as the record
  not being found or the update changeset being invalid), the entire transaction
  is rolled back.

  Each item in the input list must be either:

    * A map – used as both the `find_params` and `update_params`, or
    * A tuple `{find_params, update_params}` – allows using separate values
      for looking up and updating a record.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> updates = [
      ...>   %{id: 1, name: "Updated Name"},
      ...>   {%{id: 2}, %{name: "Another Update"}}
      ...> ]
      ...> EctoShorts.Actions.find_and_update_many(MyApp.User, updates)
      {:ok, [%User{}, %User{}]}
  """
  @spec find_and_update_many(
          query() | queryable() | source_queryable(),
          params_list :: list(map() | {map(), map()})
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec find_and_update_many(
          query() | queryable() | source_queryable(),
          params_list :: list(map() | {map(), map()}),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def find_and_update_many(query, params_list, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> multi_find_and_update(params_list, opts)
    |> Config.repo!(opts).transaction(opts)
    |> handle_multi_response()
  end

  defp multi_find_and_update(query, params_list, opts) do
    params_list
    |> Enum.with_index()
    |> Enum.reduce(Ecto.Multi.new(), fn {args, i}, multi ->
      {find_params, update_params} = unzip_find_params(args, query, opts)

      Ecto.Multi.run(multi, {:find_and_update, i}, fn repo, _changes_so_far ->
        case query
             |> CommonFilters.convert_params_to_filter(find_params, opts)
             |> repo.one(opts) do
          nil ->
            {:error,
             {:not_found, "Record not found.",
              %{
                query: query,
                position: i,
                params: params_list,
                failing_value: find_params
              }}}

          schema_data ->
            with {:error, changeset} <-
                   query
                   |> CommonSchemas.build_changeset(
                     schema_data,
                     Map.merge(find_params, update_params),
                     opts
                   )
                   |> repo.update(opts) do
              {:error,
               {:conflict, "Failed to update record.",
                %{
                  query: query,
                  position: 1,
                  changeset: changeset,
                  params: params_list
                }}}
            end
        end
      end)
    end)
  end

  @doc group: "Multi API"
  @doc since: "2.5.0"
  @doc """
  Finds and upserts many records sequentially inside a transaction.

  This function performs each operation one-by-one inside a single `Ecto.Multi`
  transaction. For each item in the input list, it tries to find a matching
  record. If found, it updates the record. If not, it inserts a new one using the
  combined values from the `find_params` and `upsert_params`.

  Each item must be either:

    * A map – used as both the `find_params` and `upsert_params`, or
    * A tuple `{find_params, upsert_params}` – used to separate the values
      for lookup and update/insert.

  If any step fails (e.g., validation errors or unexpected conflicts), the entire
  transaction is rolled back.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> items = [
      ...>   %{email: "user1@example.com", name: "User One"},
      ...>   {%{email: "user2@example.com"}, %{name: "User Two"}}
      ...> ]
      ...> EctoShorts.Actions.find_and_upsert_many(MyApp.User, items)
      {:ok, [%User{}, %User{}]}
  """
  @spec find_and_upsert_many(
          query() | queryable() | source_queryable(),
          params_list :: list(map() | {map(), map()})
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec find_and_upsert_many(
          query() | queryable() | source_queryable(),
          params_list :: list(map() | {map(), map()}),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def find_and_upsert_many(query, params_list, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> multi_find_and_upsert(params_list, opts)
    |> Config.repo!(opts).transaction(opts)
    |> handle_multi_response()
  end

  defp multi_find_and_upsert(query, params_list, opts) do
    params_list
    |> Enum.with_index()
    |> Enum.reduce(Ecto.Multi.new(), fn {args, i}, multi ->
      {find_params, upsert_params} = unzip_find_params(args, query, opts)

      Ecto.Multi.run(multi, {:find_and_upsert, i}, fn repo, _changes_so_far ->
        case query
             |> CommonFilters.convert_params_to_filter(find_params, opts)
             |> repo.one(opts) do
          nil ->
            with {:error, changeset} <-
                   query
                   |> create_changeset(Map.merge(find_params, upsert_params), opts)
                   |> repo.insert(opts) do
              {:error,
               {:conflict, "Failed to create record.",
                %{
                  query: query,
                  position: 1,
                  changeset: changeset,
                  params: params_list
                }}}
            end

          schema_data ->
            with {:error, changeset} <-
                   query
                   |> CommonSchemas.build_changeset(
                     schema_data,
                     Map.merge(find_params, upsert_params),
                     opts
                   )
                   |> repo.update(opts) do
              {:error,
               {:conflict, "Failed to update record.",
                %{
                  query: query,
                  position: 1,
                  changeset: changeset,
                  params: params_list
                }}}
            end
        end
      end)
    end)
  end

  defp unzip_find_params({find_params, params}, _query, _opts) do
    {find_params, params}
  end

  defp unzip_find_params(params, query, opts) do
    {maybe_drop_associations(params, query, opts), params}
  end

  @doc group: "Multi API"
  @doc since: "2.5.0"
  @doc """
  Creates many records sequentially inside a transaction.

  This function inserts each item in the given list one at a time using
  `Ecto.Multi`. All inserts are wrapped in a single transaction. If any
  insert fails (for example, due to a validation error), the entire
  operation is rolled back.

  This is useful when you want to guarantee that either all records are
  inserted or none are, without having to manage individual insert logic
  yourself.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> users = [
      ...>   %{email: "user1@example.com", name: "User One"},
      ...>   %{email: "user2@example.com", name: "User Two"}
      ...> ]
      ...> EctoShorts.Actions.create_many(MyApp.User, users)
      {:ok, [%User{}, %User{}]}
  """
  @spec create_many(
          query :: Ecto.Queryable.t() | {binary(), Ecto.Queryable.t()},
          params_list :: list(params())
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec create_many(
          query :: Ecto.Queryable.t() | {binary(), Ecto.Queryable.t()},
          params_list :: list(params()),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def create_many(query, params_list, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> multi_insert(params_list, opts)
    |> Config.repo!(opts).transaction(opts)
    |> handle_multi_response()
  end

  defp multi_insert(query, params_list, opts) do
    params_list
    |> Enum.with_index()
    |> Enum.reduce(Ecto.Multi.new(), fn {params, i}, multi ->
      Ecto.Multi.run(multi, {:create, i}, fn repo, _changes_so_far ->
        with {:error, changeset} <-
               query
               |> CommonSchemas.build_changeset(params, opts)
               |> repo.insert(opts) do
          {:error,
           {:conflict, "Failed to create record.",
            %{
              query: query,
              position: 1,
              changeset: changeset,
              params: params_list
            }}}
        end
      end)
    end)
  end

  @doc group: "Multi API"
  @doc since: "2.5.0"
  @doc """
  Finds many records sequentially inside a transaction.

  Each item in the list is treated as a set of search parameters, and is
  used to query for a single record using `Ecto.Multi`. All lookups are
  executed one at a time inside a single transaction. If any record is
  not found, the entire operation is rolled back.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> params_list = [
      ...>   %{email: "user1@example.com"},
      ...>   %{email: "user2@example.com"}
      ...> ]
      ...> EctoShorts.Actions.find_many(MyApp.User, params_list)
      {:ok, [%User{}, %User{}]}
  """
  @spec find_many(
          query() | queryable() | source_queryable(),
          params_list :: list(params())
        ) :: {:ok, list(schema_data())} | {:error, any()}
  @spec find_many(
          query() | queryable() | source_queryable(),
          params_list :: list(params()),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def find_many(query, params_list, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> multi_find(params_list, opts)
    |> Config.repo!(opts).transaction(opts)
    |> handle_multi_response()
  end

  defp multi_find(query, params_list, opts) do
    params_list
    |> Enum.with_index()
    |> Enum.reduce(Ecto.Multi.new(), fn {params, i}, multi ->
      Ecto.Multi.run(multi, {:find, i}, fn repo, _changes_so_far ->
        case query
             |> CommonFilters.convert_params_to_filter(params, opts)
             |> repo.one(opts) do
          nil ->
            {:error,
             {:not_found, "Record not found.",
              %{
                query: query,
                position: i,
                failing_value: params,
                params: params_list
              }}}

          schema_data ->
            {:ok, schema_data}
        end
      end)
    end)
  end

  @doc group: "Multi API"
  @doc """
  Deletes many records sequentially inside a transaction.

  Each item in the list must be a struct or changeset. All deletes are
  executed one at a time using `Ecto.Multi`. If any delete fails (for
  example, due to a constraint or validation error), the entire
  transaction is rolled back.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> users = [%User{id: 1}, %User{id: 2}]
      ...> EctoShorts.Actions.delete_many(users)
      {:ok, [%User{}, %User{}]}
  """
  @spec delete_many(schema_data_or_changesets :: list(schema_data() | changeset())) ::
          {:ok, list(schema_data())} | {:error, any()}
  @spec delete_many(
          schema_data_or_changesets :: list(schema_data() | changeset()),
          opts()
        ) :: {:ok, list(schema_data())} | {:error, any()}
  def delete_many(schema_data_or_changesets, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    schema_data_or_changesets
    |> multi_delete(opts)
    |> Config.repo!(opts).transaction(opts)
    |> handle_multi_response()
  end

  defp multi_delete(schema_data_or_changesets, opts) do
    schema_data_or_changesets
    |> Enum.with_index()
    |> Enum.reduce(Ecto.Multi.new(), fn {struct_or_changeset, i}, multi ->
      Ecto.Multi.run(multi, {:create, i}, fn repo, _changes_so_far ->
        with {:error, changeset} <-
               struct_or_changeset
               |> CommonSchemas.build_changeset(%{}, opts)
               |> repo.delete(opts) do
          {:error,
           {:conflict, "Failed to delete record.",
            %{
              query: CommonSchemas.get_schema_metadata(struct_or_changeset).schema,
              position: 1,
              changeset: changeset,
              params: schema_data_or_changesets
            }}}
        end
      end)
    end)
  end

  defp handle_multi_response(
         {:error, _failed_operation, {code, message, details}, changes_so_far}
       ) do
    {:error,
     Error.call(
       code,
       message,
       Map.put(details, :changes_so_far, Map.values(changes_so_far))
     )}
  end

  defp handle_multi_response({:ok, operations}) do
    {:ok, Map.values(operations)}
  end

  @doc group: "Query API"
  @doc """
  Finds a record using one set of parameters, and creates it using
  another if not found.

  This function allows you to use different values for searching and
  inserting. It first attempts to find a record using `find_params`.
  If no match is found, it merges `find_params` with `create_params`
  and inserts a new record.

  This is useful when you want to enforce uniqueness on specific
  fields (e.g. `email`) but need to provide additional data when
  inserting.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> find_params = %{email: "user@example.com"}
      ...> create_params = %{email: "user@example.com", name: "New User"}
      ...> EctoShorts.Actions.find_and_create(MyApp.User, find_params, create_params)
      {:ok, %User{}}
  """
  @spec find_and_create(query() | queryable() | source_queryable(), params(), params()) ::
          {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec find_and_create(
          query() | queryable() | source_queryable(),
          params(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def find_and_create(query, find_params, create_params, opts \\ []) do
    with {:error, %{code: :not_found}} <- find(query, find_params, opts) do
      query
      |> CommonQueries.get_query_source()
      |> create(create_params, opts)
    end
  end

  @doc group: "Query API"
  @doc """
  Finds a record using `find_params` and updates it with the combined
  data from both `find_params` and `update_params`.

  This function is useful when you want to update a record if it exists,
  without needing to manually fetch and apply changes. It first attempts
  to find the record, and if successful, merges the params and updates
  the result.

  If the record is not found, an error is returned.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> EctoShorts.Actions.find_and_update(MyApp.User, %{id: 1}, %{name: "Updated Name"})
      {:ok, %User{name: "Updated Name"}}
  """
  @spec find_and_update(
          query() | queryable() | source_queryable(),
          params(),
          params()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec find_and_update(
          query() | queryable() | source_queryable(),
          params(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def find_and_update(query, find_params, update_params, opts \\ []) do
    with {:ok, struct} <- find(query, find_params, opts) do
      query
      |> CommonQueries.get_query_source()
      |> update(struct, update_params, opts)
    end
  end

  @doc group: "Query API"
  @doc """
  Finds a record using `find_params` and updates it with `update_params`.
  If the record is not found, a new one is created using the combined
  params.

  This function is useful when you want to either update an existing
  record or insert a new one in its place, commonly referred to as an
  "upsert" operation. It automatically decides whether to update or
  create based on whether a match is found.

  If an update fails (e.g. due to validation errors), an error is
  returned. If a create fails, an error is also returned.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> EctoShorts.Actions.find_and_upsert(MyApp.User, %{email: "fira@example.com"}, %{name: "Fira"})
      {:ok, %User{}}
  """
  @spec find_and_upsert(
          query() | queryable() | source_queryable(),
          params(),
          params()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec find_and_upsert(
          query() | queryable() | source_queryable(),
          params(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def find_and_upsert(query, find_params, update_params, opts \\ []) do
    case find(query, find_params, opts) do
      {:ok, struct} ->
        update(query, struct, update_params, opts)

      {:error, %{code: :not_found}} ->
        create(query, Map.merge(find_params, update_params), opts)

      {:error, _} = e ->
        e
    end
  end

  @doc group: "Query API"
  @doc """
  Finds a record by the given parameters and deletes it.

  This function combines a `find/3` followed by a `delete/2`. If the
  record is found, it is deleted. If no matching record is found,
  an error is returned.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> EctoShorts.Actions.find_and_delete(MyApp.User, %{id: 1})
      {:ok, %User{}}

      iex> EctoShorts.Actions.find_and_delete({"users", MyApp.User}, %{email: "fira@example.com"}, repo: MyApp.Repo)
      {:ok, %User{}}
  """
  @spec find_and_delete(
          query() | queryable() | source_queryable(),
          params()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec find_and_delete(
          query() | queryable() | source_queryable(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def find_and_delete(query, find_params, opts \\ []) do
    with {:ok, struct} <- find(query, find_params, opts) do
      delete(struct, opts)
    end
  end

  @doc group: "Query API"
  @doc """
  Finds a record by the given parameters or creates it if not found.

  This function simplifies the common pattern of checking for the existence
  of a record and inserting it if it doesn’t exist. It runs the find operation
  first, and if no record is found, falls back to create.

  This is helpful for enforcing uniqueness based on arbitrary fields, while
  avoiding race conditions in most simple use cases.

  The same parameter map is used for both the find and create steps.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ### Additional Options

    * `:drop_associations` – When true (default), any schema associations
      in the parameter map will be excluded before the find query. This avoids
      unexpected behavior due to association joins during lookup.

  ## Examples

      iex> EctoShorts.Actions.find_or_create(MyApp.User, %{email: "fira@example.com"})
      {:ok, %User{}}

      iex> EctoShorts.Actions.find_or_create({"users", MyApp.User}, %{email: "fira@example.com"}, repo: MyApp.Repo)
      {:ok, %User{}}
  """
  @spec find_or_create(
          query() | queryable() | source_queryable(),
          params()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec find_or_create(
          query() | queryable() | source_queryable(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def find_or_create(query, params, opts \\ []) do
    with {:error, %{code: :not_found}} <-
           find(query, maybe_drop_associations(params, query, opts), opts) do
      query
      |> CommonQueries.get_query_source()
      |> create(params, opts)
    end
  end

  @doc group: "Query API"
  @doc """
  Fetches a single record by its primary key.

  This is a convenience wrapper around [`Ecto.Repo.get/3`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:get/3), with added support
  for using a replica repo when provided.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.get/3`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:get/3) are also supported.

  ## Examples

      iex> EctoShorts.Actions.get(MyApp.User, 1)
      %User{id: 1}

      iex> EctoShorts.Actions.get(MyApp.User, 1, repo: MyApp.Repo)
      %User{id: 1}

      iex> EctoShorts.Actions.get({"users", MyApp.User}, "abc-123", replica: MyApp.Repo.Replica)
      %User{id: "abc-123"}
  """
  @spec get(
          query() | queryable() | source_queryable(),
          id :: id()
        ) :: schema_data() | nil
  @spec get(
          query() | queryable() | source_queryable(),
          id :: id(),
          opts()
        ) :: schema_data() | nil
  def get(query, id, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    Config.replica!(opts).get(query, id, opts)
  end

  @doc group: "Query API"
  @doc """
  Fetches all records using the given filters and options.

  This is a convenience version of `all/3` that accepts either a map of filters
  or a keyword list that mixes filters with options like `:repo` or `:replica`.

  If a map is given, it is treated as filter parameters.

  If a keyword list is given, all non-option keys are treated as filters, and
  recognized options like `:repo`, `:replica`, `:order_by`, and `:group_by` are extracted.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  ## Examples

      iex> EctoShorts.Actions.all(MyApp.User, %{id: 1})
      [%User{id: 1}]

      iex> EctoShorts.Actions.all(MyApp.User, id: 1, repo: MyApp.Repo)
      [%User{id: 1}]

      iex> EctoShorts.Actions.all(MyApp.User, id: 1, replica: MyApp.Repo.Replica)
      [%User{id: 1}]
  """
  @spec all(query() | queryable() | source_queryable()) :: list(schema_data())
  @spec all(query() | queryable() | source_queryable(), params()) ::
          list(schema_data())
  @spec all(query() | queryable() | source_queryable(), opts()) ::
          list(schema_data())
  def all(query, params_or_opts \\ [])

  def all(query, params) when is_map(params) do
    all(query, params, [])
  end

  def all(query, opts) do
    params =
      opts
      |> Keyword.drop([:repo, :replica])
      |> Map.new()

    all(query, params, Keyword.take(opts, [:repo, :replica]))
  end

  @doc group: "Query API"
  @doc """
  Fetches all records matching the given query and filter parameters.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  Additional supported options:

    * `:group_by` – Group results by one or more fields.
    * `:order_by` – Sort results by one or more fields.

  All options accepted by [`Ecto.Repo.all/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:all/2) are also supported.

  ## Examples

      iex> EctoShorts.Actions.all(MyApp.User, %{role: "admin"})
      [%User{role: "admin"}]

      iex> EctoShorts.Actions.all(MyApp.User, role: "admin", order_by: :inserted_at, repo: MyApp.Repo)
      [%User{role: "admin"}]

      iex> EctoShorts.Actions.all({"users", MyApp.User}, %{role: "admin"}, replica: MyApp.Repo.Replica)
      [%User{role: "admin"}]
  """
  @spec all(
          query() | queryable() | source_queryable(),
          params(),
          opts()
        ) :: list(schema_data())
  def all(query, params, opts) do
    opts = Keyword.merge(default_opts(), opts)

    params =
      params
      |> put_order_by(opts)
      |> put_group_by(opts)

    opts = Keyword.drop(opts, [:order_by, :group_by])

    query
    |> CommonFilters.convert_params_to_filter(params, opts)
    |> Config.replica!(opts).all(opts)
  end

  @doc group: "Schema API"
  @doc """
  Inserts a new record into the database.

  This function builds a changeset from the given params and inserts it using
  the specified repo.

  If the schema defines a `create_changeset/1` function and no `:build_changeset`
  option is given, it will be used automatically.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options supported by [`Ecto.Repo.insert/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:insert/2) are also accepted.

  ## Examples

      iex> EctoShorts.Actions.create(MyApp.User, %{name: "Fira"}, repo: MyApp.Repo)
      {:ok, %User{name: "Fira"}}

      iex> EctoShorts.Actions.create({"users", MyApp.User}, %{name: "Fira"}, repo: MyApp.Repo)
      {:ok, %User{name: "Fira"}}
  """
  @spec create(
          query :: Ecto.Queryable.t() | {binary(), Ecto.Queryable.t()},
          params()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec create(
          query :: Ecto.Queryable.t() | {binary(), Ecto.Queryable.t()},
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def create(query, params, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> create_changeset(params, opts)
    |> Config.repo!(opts).insert(opts)
  end

  @doc group: "Query API"
  @doc """
  Fetches a single record that matches the given parameters.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.one/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:one/2)
  are also supported.

  ## Examples

      iex> EctoShorts.Actions.find(MyApp.User, %{id: 1}, repo: MyApp.Repo)
      {:ok, %User{id: 1}}

      iex> EctoShorts.Actions.find(MyApp.User, %{email: "notfound@example.com"})
      {:error, %{code: :not_found, message: "Record not found.", ...}}

      iex> EctoShorts.Actions.find({"users", MyApp.User}, %{id: 1})
      {:ok, %User{id: 1}}
  """
  @spec find(
          query() | queryable() | source_queryable(),
          params()
        ) :: {:ok, schema_data()} | {:error, any()}
  @spec find(
          query() | queryable() | source_queryable(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, any()}
  def find(query, params, opts \\ [])

  def find(query, params, opts) when params === %{} do
    {:error,
     Error.call(
       :not_found,
       "Record not found.",
       %{
         query: query,
         params: params
       },
       opts
     )}
  end

  def find(query, params, opts) do
    opts = Keyword.merge(default_opts(), opts)

    params =
      params
      |> put_order_by(opts)
      |> put_group_by(opts)

    opts = Keyword.drop(opts, [:order_by, :group_by])

    result =
      query
      |> CommonFilters.convert_params_to_filter(params, opts)
      |> Config.replica!(opts).one(opts)

    case result do
      nil ->
        {:error,
         Error.call(
           :not_found,
           "Record not found.",
           %{
             query: query,
             params: params
           },
           opts
         )}

      struct ->
        {:ok, struct}
    end
  end

  @doc group: "Schema API"
  @doc """
  Updates a record using either an ID or an existing struct.

  This function allows you to provide either:

    * a primary key (e.g. `123`) — the record will be looked up by `id`
    * an existing struct — the update will be applied directly

  The provided `update_params` are passed through the schema’s changeset
  logic and then persisted via [`Ecto.Repo.update/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:update/2).

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.update/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:update/2)
  are also supported.

  ## Examples

      # Using a primary key:

      iex> EctoShorts.Actions.update(MyApp.User, 1, %{name: "New Name"})
      {:ok, %User{name: "New Name"}}

      # Using a struct:

      iex> user = %User{id: 1, name: "Old Name"}
      iex> EctoShorts.Actions.update(MyApp.User, user, %{name: "Updated"})
      {:ok, %User{name: "Updated"}}

      # Using a tuple source:

      iex> user = %User{id: 1}
      iex> EctoShorts.Actions.update({"users", MyApp.User}, user, %{name: "Updated"})
      {:ok, %User{name: "Updated"}}
  """
  @spec update(
          query() | queryable() | source_queryable(),
          id_or_struct :: integer() | binary() | schema_data(),
          params()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  @spec update(
          query() | queryable() | source_queryable(),
          id_or_struct :: integer() | binary() | schema_data(),
          params(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def update(query, id_or_struct, update_params, opts \\ [])

  def update(query, id, update_params, opts) when is_integer(id) or is_binary(id) do
    with {:ok, struct} <- find(query, %{id: id}, opts) do
      query
      |> CommonSchemas.get_schema_queryable()
      |> update(struct, update_params, opts)
    end
  end

  def update(query, struct, update_params, opts) when is_list(update_params) do
    update(query, struct, Map.new(update_params), opts)
  end

  def update(query, struct, update_params, opts) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> CommonSchemas.build_changeset(struct, update_params, opts)
    |> Config.repo!(opts).update(opts)
  end

  @doc group: "Schema API"
  @doc """
  Deletes a record given a struct or changeset.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.delete/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:delete/2)
  are also supported.

  ## Examples

      iex> EctoShorts.Actions.delete(MyApp.User, 1)
      {:ok, %User{}}

      iex> EctoShorts.Actions.delete(MyApp.User, "abc123")
      {:ok, %User{}}

      iex> EctoShorts.Actions.delete({"users", MyApp.User}, 1)
      {:ok, %User{}}
  """
  @spec delete(
          schema_data_or_changesets ::
            schema_data() | changeset() | list(schema_data() | changeset())
        ) :: {:ok, list(schema_data())} | {:error, list(changeset())} | {:error, any()}
  @spec delete(
          struct_or_changeset ::
            schema_data() | changeset() | list(schema_data() | changeset()),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def delete(schema_data_or_changesets, opts \\ [])

  def delete(%_{data: %_{__meta__: %{schema: queryable}}} = changeset, opts) do
    opts = Keyword.merge(default_opts(), opts)

    with {:error, changeset} <-
           queryable
           |> CommonSchemas.build_changeset(changeset, %{}, opts)
           |> Config.repo!(opts).delete(opts) do
      {:error,
       Error.call(
         :conflict,
         "Failed to delete record.",
         %{
           query: queryable,
           changeset: changeset,
           schema_data: changeset.data
         },
         opts
       )}
    end
  end

  def delete(%_{__meta__: %{schema: queryable}} = struct, opts) do
    opts = Keyword.merge(default_opts(), opts)

    with {:error, changeset} <-
           queryable
           |> CommonSchemas.build_changeset(struct, %{}, opts)
           |> Config.repo!(opts).delete(opts) do
      {:error,
       Error.call(
         :conflict,
         "Failed to delete record.",
         %{
           query: queryable,
           changeset: changeset,
           schema_data: struct
         },
         opts
       )}
    end
  end

  def delete(schema_data_or_changesets, opts) when is_list(schema_data_or_changesets) do
    Utils.reduce_all(schema_data_or_changesets, fn struct_or_changeset ->
      delete(struct_or_changeset, opts)
    end)
  end

  def delete(query, id) when is_binary(id) or is_integer(id) do
    delete(query, id, [])
  end

  @doc group: "Schema API"
  @doc """
  Deletes a record using its primary key.

  If the record is not found, an error is returned.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.delete/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:delete/2)
  are also supported.

  ## Examples

      iex> EctoShorts.Actions.delete(MyApp.User, 1, repo: MyApp.Repo)
      {:ok, %User{}}

      iex> EctoShorts.Actions.delete(MyApp.User, "abc123", replica: MyApp.Repo.Replica)
      {:ok, %User{}}

      iex> EctoShorts.Actions.delete({"users", MyApp.User}, 1, repo: MyApp.Repo)
      {:ok, %User{}}
  """
  @spec delete(
          query() | queryable() | source_queryable(),
          id :: id(),
          opts()
        ) :: {:ok, schema_data()} | {:error, changeset()} | {:error, any()}
  def delete(query, id, opts) when is_integer(id) or is_binary(id) do
    with {:ok, struct} <- find(query, %{id: id}, opts) do
      delete(struct, opts)
    end
  end

  @doc group: "Query API"
  @doc """
  Streams all records that match the given filters.

  This returns a lazy enumerable that can be used to iterate over large
  datasets without loading them all into memory at once.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.stream/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:stream/2)
  are also supported.

  ## Examples

      iex> stream = EctoShorts.Actions.stream(MyApp.User, %{role: "admin"}, repo: MyApp.Repo)
      ...> Enum.to_list(stream)
      [%User{}, %User{}]

      iex> stream =
      ...>   EctoShorts.Actions.stream({"users", MyApp.User}, %{active: true}, repo: MyApp.Repo)
      ...> Enum.take(stream, 10)
      [%User{}, ...]
  """
  @spec stream(query() | queryable() | source_queryable()) :: stream()
  @spec stream(query() | queryable() | source_queryable(), params()) :: stream()
  @spec stream(query() | queryable() | source_queryable(), params(), opts()) :: stream()
  def stream(query, params \\ %{}, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> CommonFilters.convert_params_to_filter(params, opts)
    |> Config.repo!(opts).stream(opts)
  end

  @doc group: "Query API"
  @doc """
  Calculates an aggregate value from a filtered query.

  This function applies the given filter parameters and computes an
  aggregate (like `:count`, `:sum`, or `:avg`) over a specified field.

  ## Supported Aggregates

    * `:count` – count matching rows
    * `:sum` – sum of values in the field
    * `:avg` – average of values in the field
    * `:min` – minimum value in the field
    * `:max` – maximum value in the field

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.aggregate/4`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:aggregate/4)
  are also supported.

  ## Examples

      iex> EctoShorts.Actions.aggregate(MyApp.User, %{active: true}, :count, :id)
      42

      iex> EctoShorts.Actions.aggregate(MyApp.User, %{role: "admin"}, :avg, :login_count, repo: MyApp.Repo)
      5.75
  """
  @spec aggregate(
          query() | queryable() | source_queryable(),
          params(),
          aggregate_options(),
          field()
        ) :: any() | nil
  @spec aggregate(
          query() | queryable() | source_queryable(),
          params(),
          aggregate_options(),
          field(),
          opts()
        ) :: any() | nil
  def aggregate(query, params, aggregate, field, opts \\ []) do
    opts = Keyword.merge(default_opts(), opts)

    query
    |> CommonFilters.convert_params_to_filter(params, opts)
    |> Config.replica!(opts).aggregate(aggregate, field, opts)
  end

  @doc group: "Transaction API"
  @doc since: "2.5.0"
  @doc """
  Runs a function or `Ecto.Multi` inside a database transaction.

  This function wraps the given operation in a transaction using the
  configured `:repo`. You can pass either a function or a pre-built
  `Ecto.Multi` struct.

  If a function is passed, it can be either:

    * a zero-arity function (`fn -> ... end`)
    * a one-arity function that receives the `repo` as its argument (`fn repo -> ... end`)

  By default, the transaction is automatically rolled back if the
  function executed inside the transaction returns `:error` or
  `{:error, reason}`.

  You can disable this behavior by passing `rollback_on_error: false`.

  All other values will commit the transaction.

  ## Options

  See the [Shared Options](EctoShorts.Actions.html#module-shared-options).

  All options accepted by [`Ecto.Repo.transaction/2`](https://hexdocs.pm/ecto/Ecto.Repo.html#c:transaction/2) are supported.

  ## Examples

      # Run a transactional function:

      iex> EctoShorts.Actions.transaction(fn ->
      ...>   EctoShorts.Actions.create(MyApp.User, %{name: "Jane"})
      ...> end)

      # Use a one-arity function:

      iex> EctoShorts.Actions.transaction(fn repo ->
      ...>   repo.insert!(%MyApp.User{name: "Jane"})
      ...> end)

      # Run a pre-built Ecto.Multi:

      iex> multi = Ecto.Multi.new()
      ...> |> Ecto.Multi.insert(:user, MyApp.User.changeset(%MyApp.User{}, %{name: "Jane"}))
      ...> EctoShorts.Actions.transaction(multi)
  """
  @spec transaction(fun_or_multi :: function() | multi()) ::
          {:ok, any()} | {:error, any()} | multi_failure()
  @spec transaction(
          fun_or_multi :: function() | multi(),
          opts()
        ) :: {:ok, any()} | {:error, any()} | multi_failure()
  def transaction(fun_or_multi, opts \\ [])

  def transaction(%_{} = multi, opts) do
    opts = Keyword.merge(default_opts(), opts)

    Config.repo!(opts).transaction(multi, opts)
  end

  def transaction(fun, opts) do
    opts = Keyword.merge(default_opts(), opts)

    op = fn repo ->
      result = if is_function(fun, 1), do: fun.(repo), else: fun.()

      if Keyword.get(opts, :rollback_on_error, true) do
        case result do
          :error ->
            repo.rollback(:error)

          {:error, reason} ->
            repo.rollback(reason)

          {:ok, value} ->
            value

          term ->
            term
        end
      else
        result
      end
    end

    case Config.repo!(opts).transaction(op, opts) do
      {:error, :error} -> :error
      {:ok, :ok} -> :ok
      result -> result
    end
  end

  defp create_changeset(query, params, opts) do
    schema_module = CommonSchemas.get_schema_queryable(query)

    if function_exported?(schema_module, :create_changeset, 1) and
         not Keyword.has_key?(opts, :build_changeset) do
      schema_module.create_changeset(params)
    else
      CommonSchemas.build_changeset(query, params, opts)
    end
  end

  defp maybe_drop_associations(params, query, opts) do
    if Keyword.get(opts, :drop_associations, true) do
      drop_associations(params, query)
    else
      params
    end
  end

  defp drop_associations(params, query) do
    Map.drop(params, CommonSchemas.get_schema_queryable(query).__schema__(:associations))
  end

  defp put_order_by(params, opts) do
    case Keyword.get(opts, :order_by) do
      nil -> params
      order_by -> Map.put(params, :order_by, order_by)
    end
  end

  defp put_group_by(params, opts) do
    case Keyword.get(opts, :group_by) do
      nil -> params
      group_by -> Map.put(params, :group_by, group_by)
    end
  end

  defp default_opts do
    []
    |> maybe_put_opt(:repo, Config.repo())
    |> maybe_put_opt(:replica, Config.replica())
  end

  defp maybe_put_opt(opts, _key, nil), do: opts
  defp maybe_put_opt(opts, key, val), do: Keyword.put(opts, key, val)
end
