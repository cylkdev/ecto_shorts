defmodule EctoShorts.CommonQueryAPI.DynamicExpression do

  alias EctoShorts.CommonQueryAPI.DynamicExpression

  @default_dynamic_expression_adapter DynamicExpression.Postgres

  @callback build_dynamic_expression(any(), any(), any(), any(), any()) :: any()

  def build_dynamic_expression(dyn, current_binding, schema_module, key, value, opts) do
    dynamic_expression_adapter(opts).build_dynamic_expression(
      dyn,
      current_binding,
      schema_module,
      key,
      value
    )
  end

  defp dynamic_expression_adapter(opts) do
    opts[:dynamic_expression_adapter] ||
      EctoShorts.Config.dynamic_expression_adapter() ||
      @default_dynamic_expression_adapter
  end
end
