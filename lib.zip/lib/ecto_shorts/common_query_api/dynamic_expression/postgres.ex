defmodule EctoShorts.CommonQueryAPI.DynamicExpression.Postgres do
  @moduledoc since: "2.5.0"
  @moduledoc """
  Build dynamic `where` and `or_where` filters for Postgres without
  writing raw `Ecto.Query` expressions.

  This module makes it easier to add dynamic filters to your Ecto
  queries, especially when the filters come from user input or need
  to change at runtime.

  Instead of writing out each condition manually, you can pass in a
  map or keyword list of filters. It handles building the right
  expressions for each field based on its type—so you don’t need to
  worry about whether a field is a string, number, or array.

  This api allows you to:

    * Add filters based on a map of parameters (like controller input)

    * Support flexible operators (`:==`, `:!=`, `:<`, `:ilike`, etc.)

    * Match values inside Postgres array fields (e.g., `tags`)

    * Compose multiple filters using `where` and `or_where`

  You get all this without needing to use `Ecto.Query` macros or worry
  about query bindings.

  ## Example

  Here's a query that filters users who are active and over 30:

      filters = %{active: true, age: {:>=, 30}}

      User
      |> EctoShorts.CommonQueryAPI.DynamicExpression.Postgres.where(:user, filters)

  You can also use `or_where/3` to combine filters with `OR` logic:

      EctoShorts.CommonQueryAPI.DynamicExpression.Postgres.or_where(User, :user, [
        %{status: "archived"},
        %{status: "disabled"}
      ])

  ## How It Works

  This module decides what kind of filter to apply based on the field’s type:

    * If the field is an array, it uses Postgres array operators (like `ILIKE ANY`).

    * If the field is a regular value, it uses standard comparisons or pattern matches.

  It delegates the actual filtering to these helpers:

    * `Postgres.Array` – For filters on array fields

    * `Postgres.Field` – For filters on regular (scalar) fields

  In most cases, you won’t need to think about these directly and just
  use the `where/3` and `or_where/3` functions and pass in your data.
  """

  alias EctoShorts.{
    CommonQueryAPI,
    CommonQueryAPI.DynamicExpression.Postgres.Array,
    CommonQueryAPI.DynamicExpression.Postgres.Field
  }

  @type source :: binary()
  @type query :: Ecto.Query.t()
  @type queryable :: Ecto.Queryable.t()
  @type source_queryable :: {source(), queryable()}
  @type binding_alias :: atom() | nil
  @type params :: map() | keyword()
  @type key :: atom()
  @type value :: any()
  @type operator :: any()

  def build_dynamic_expression(dyn, current_binding, schema_module, key, {operator, value}) do
    cond do
      field_type_of_array?(schema_module, key) and is_list(value) ->
        CommonQueryAPI.merge_dynamic(dyn, Array.where(current_binding, key, operator, value))

      field_type_of_array?(schema_module, key) ->
        CommonQueryAPI.merge_dynamic(dyn, Array.where(current_binding, value, operator, key))

      true ->
        CommonQueryAPI.merge_dynamic(dyn, Field.where(current_binding, key, operator, value))
    end
  end

  def build_dynamic_expression(dyn, current_binding, schema_module, key, value) do
    build_dynamic_expression(dyn, current_binding, schema_module, key, {:==, value})
  end

  defp field_type(schema_module, key) do
    schema_module.__schema__(:type, key)
  end

  defp field_type_of_array?(schema_module, key) do
    case field_type(schema_module, key) do
      {:array, _} -> true
      _ -> false
    end
  end
end
