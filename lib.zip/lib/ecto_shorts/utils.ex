defmodule EctoShorts.Utils do
  @moduledoc false

  @doc """
  Recursively applies a function to each element or key-value pair in
  the input, traversing lists and maps.

  The function is called as `fun.(query, value)` or
  `fun.(query, {key, value})`, depending on the shape of the input.

  ## Deep Nesting and Key Expansion

  When the input is a nested map or keyword list, `apply_expressions/3`
  recursively expands the structure, passing deeply nested key-value
  pairs as tuples. For example, given:

    `%{a: %{b: %{c: 1}}}`

  The function will ultimately call:

    `fun.(query, {:a, {:b, {:c, 1}}})`

  This pattern preserves the full nesting path as a tuple, making it easy
  to work with arbitrarily deep structures. It's especially useful when
  building queries from complex filter or select parameters, where
  maintaining key context is important.

  ## Example

      params = %{user: %{profile: %{age: 30}}}

      EctoShorts.EctoShorts.CommonQueryAPI.Helpers.apply_expressions(query, params, fn
        query, {:user, {:profile, {:age, 30}}} ->
        # ...
      end)
  """
  @spec apply_expressions(
          query :: any(),
          value :: any(),
          fun :: (query :: any(), value :: any() -> any())
        ) :: any()
  def apply_expressions(query, {key, values}, fun) when is_list(values) do
    if Keyword.keyword?(values) or has_params?(values) do
      Enum.reduce(values, query, fn value, query ->
        apply_expressions(query, value, fun)
      end)
    else
      fun.(query, {key, values})
    end
  end

  def apply_expressions(query, {key, data}, fun) when is_map(data) do
    if is_struct(data) do
      fun.(query, {key, data})
    else
      Enum.reduce(data, query, fn value, query ->
        apply_expressions(query, {key, value}, fun)
      end)
    end
  end

  def apply_expressions(query, {key, value}, fun) do
    fun.(query, {key, value})
  end

  def apply_expressions(query, values, fun) when is_list(values) do
    if Keyword.keyword?(values) or has_params?(values) do
      Enum.reduce(values, query, fn value, query ->
        apply_expressions(query, value, fun)
      end)
    else
      fun.(query, values)
    end
  end

  def apply_expressions(query, params, fun) when is_map(params) do
    Enum.reduce(params, query, fn {key, value}, query ->
      apply_expressions(query, {key, value}, fun)
    end)
  end

  def apply_expressions(query, value, fun) do
    fun.(query, value)
  end

  defp has_params?([head | _]) when is_list(head) or is_map(head), do: true
  defp has_params?(_), do: false

  @doc """
  Reduces an enumerable by applying a function that returns `{:ok, value}` or
  `{:error, reason}` to each item, accumulating successes and errors separately.

  If all elements return `{:ok, value}`, returns `{:ok, list_of_values}`.
  If any element returns `{:error, term}`, returns `{:error, list_of_terms}`.

  You can set the initial accumulator for successful values by `value_acc` or
  the initial accumulator for errors by `error_acc`.

  ### Examples

      iex> SharedUtils.Enum.reduce_all([1], fn v -> {:ok, v} end)
      {:ok, [1]}

      iex> SharedUtils.Enum.reduce_all(["error"], fn v -> {:error, v} end)
      {:error, ["error"]}
  """
  @spec reduce_all(enum :: Enum.t(), fun :: function()) :: {:ok, list()} | {:error, list()}
  def reduce_all(enum, fun) do
    case Enum.reduce(enum, {[], []}, &reduce_eval(&1, fun, &2)) do
      {values, []} -> {:ok, Enum.reverse(values)}
      {_, errors} -> {:error, Enum.reverse(errors)}
    end
  end

  defp reduce_eval(term, fun, {values, errors}) do
    case fun.(term) do
      {:error, e} -> {values, [e | errors]}
      {:ok, v} -> {[v | values], errors}
      term -> raise "expected {:ok, term()} or {:error, term()}, got: #{inspect(term)}"
    end
  end

  def underscore_last_module_alias(module) do
    module
    |> Module.split()
    |> List.last()
    |> Macro.underscore()
  end
end
