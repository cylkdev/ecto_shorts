defmodule EctoShorts.CommonChanges do
  @moduledoc """
  `EctoShorts.CommonChanges` provides utility functions to simplify `changeset/2` creation.

  These helpers streamline tasks like association handling, defaulting values conditionally,
  and validating fields based on user input or business rules.

  ## Features

  ### 1. Preloading Associations on Change

  ️Preloads an association when present in input params, and automatically applies
  `cast_assoc/3` or `put_assoc/4`. This allows passing a related struct or map
  without manually preloading it in a controller.

  ```elixir
      def changeset(changeset, params) do
        changeset
        |> cast(params, [:name, :email])
        |> preload_change_assoc(:address)
      end
  ```

  ### 2. Conditional Field Defaults

  Set or modify values only when a given condition is met:

  ```elixir
      EctoShorts.CommonChanges.put_when(
        &CommonChanges.changeset_field_nil?(&1, :email),
        &put_change(&1, :email, "default@email.com")
      )
  ```

  ### 3. Validating Relations

  Ensure a relation is present via foreign key or struct:

  ```elixir
      EctoShorts.preload_change_assoc(changeset, :address, required_when_missing: :address_id)
  ```

  This approach ensures strong association handling without cluttering the schema logic.
  """
  alias Ecto.Changeset

  alias EctoShorts.{
    Actions,
    SchemaIntrospection
  }

  @typedoc "An Ecto changeset being transformed or validated."
  @type changeset :: Ecto.Changeset.t()

  @typedoc "A field name (typically an atom)."
  @type key :: atom()

  @type precision :: :microsecond | :millisecond | :second

  @typedoc """
  A keyword-list of options.
  """
  @type opts :: keyword()

  @filename_web_safe_regex ~r|^[ A-Za-z0-9\-\_\.\(\)]+$|u

  @doc since: "2.5.0"
  @doc """
  Validates that the given field contains only safe characters.

  This includes alphanumeric characters, space, and the following:
  `- _ . ( )`

  You may also provide `:min` and `:max` length options.
  """
  @spec validate_filename(changeset(), key(), opts()) :: changeset()
  def validate_filename(changeset, key \\ :filename, opts \\ []) do
    changeset
    |> Changeset.validate_change(key, fn
      ^key, nil ->
        []

      ^key, change ->
        message =
          "Can only contain characters alphanumeric characters " <>
            "(A-Z, a-z, 0-9) or special characters space, hyphen (-), " <>
            "underscore(_), and period (.)."

        if Regex.match?(@filename_web_safe_regex, change), do: [], else: [{key, message}]
    end)
    |> Changeset.validate_length(key, min: opts[:min] || 1, max: opts[:max] || 255)
  end

  @doc since: "2.5.0"
  @doc """
  Truncates a `NaiveDateTime` field change to the specified precision.
  """
  @spec truncate_naive_datetime_change(changeset(), key(), precision()) :: changeset()
  def truncate_naive_datetime_change(changeset, key, precision \\ :second) do
    Changeset.update_change(changeset, key, fn
      datetime when is_struct(datetime, NaiveDateTime) ->
        NaiveDateTime.truncate(datetime, precision)

      term ->
        term
    end)
  end

  @doc since: "2.5.0"
  @doc """
  Truncates a `DateTime` field change to the specified precision.
  """
  @spec truncate_datetime_change(changeset(), key(), precision()) :: changeset()
  def truncate_datetime_change(changeset, key, precision \\ :second) do
    Changeset.update_change(changeset, key, fn
      datetime when is_struct(datetime, DateTime) ->
        DateTime.truncate(datetime, precision)

      term ->
        term
    end)
  end

  @doc since: "2.5.0"
  @doc """
  Applies the function to a changeset if the `key` hasn't already been changed.
  """
  @spec put_new_change(changeset(), key(), function()) :: changeset()
  def put_new_change(changeset, key, fun) do
    case Changeset.get_change(changeset, key) do
      nil -> fun.(changeset)
      _ -> changeset
    end
  end

  @doc """
  Applies the function to a changeset if a condition evaluates to `true`.
  """
  @spec put_when(
          changeset(),
          (changeset() -> boolean()),
          (changeset() -> changeset())
        ) :: changeset()
  def put_when(changeset, when_func, func) do
    if when_func.(changeset) do
      func.(changeset)
    else
      changeset
    end
  end

  @doc since: "2.5.0"
  @doc """
  Returns true if the field on the changeset is an empty list or map.
  """
  @spec changeset_change_empty?(changeset(), key()) :: boolean()
  def changeset_change_empty?(changeset, key) do
    case Changeset.get_change(changeset, key) do
      change when is_list(change) -> change === []
      change when is_map(change) -> change === %{}
      _ -> false
    end
  end

  @doc since: "2.5.0"
  @doc """
  Returns true if the change for the given key is nil.
  """
  @spec changeset_change_nil?(changeset(), key()) :: boolean()
  def changeset_change_nil?(changeset, key) do
    changeset
    |> Changeset.get_change(key)
    |> is_nil()
  end

  @doc """
  Returns true if the field on the changeset is an empty list in
  the data or changes.

  ### Examples

      iex> EctoShorts.CommonChanges.changeset_field_empty?(changeset, :comments)
  """
  @spec changeset_field_empty?(changeset(), key()) :: boolean()
  def changeset_field_empty?(changeset, key) do
    case Changeset.get_field(changeset, key) do
      change when is_list(change) -> change === []
      change when is_map(change) -> change === %{}
      _ -> false
    end
  end

  @doc """
  Returns true if the field on the changeset is nil in the data or changes.

  ### Examples

      iex> EctoShorts.CommonChanges.changeset_field_nil?(changeset, :comments)
  """
  @spec changeset_field_nil?(changeset(), key()) :: boolean()
  def changeset_field_nil?(changeset, key) do
    changeset
    |> Changeset.get_field(key)
    |> is_nil()
  end

  @doc """
  Shortcut version of `preload_change_assoc/3` that uses default options.

  Only preloads and casts if the key is present in the params. Otherwise,
  falls back to a regular `cast_assoc/3`.
  """
  @spec preload_change_assoc(changeset(), key()) :: changeset()
  def preload_change_assoc(changeset, key) do
    if Map.has_key?(changeset.params, Atom.to_string(key)) do
      changeset
      |> preload_changeset_assoc(key)
      |> put_or_cast_assoc(key)
    else
      Changeset.cast_assoc(changeset, key)
    end
  end

  @doc """
  Preloads an association if present in the changeset params and applies
  either `cast_assoc/3` or `put_assoc/3`, depending on the data shape.

  This function allows direct usage of embedded maps or structs in the params
  without requiring manual preload in your controller or context logic.

  ## Options

    * `:required` - If set to `true`, validates that the association is not nil.

    * `:required_when_missing` - If the given field is `nil` in both changes and data, `:required` will be set to true.

    * `:repo` - Optional. Overrides the default repo used for preloading.

  ## Example

    iex> EctoShorts.CommonChanges.preload_change_assoc(changeset, :profile)
    iex> EctoShorts.CommonChanges.preload_change_assoc(changeset, :account, required: true)
    iex> EctoShorts.CommonChanges.preload_change_assoc(changeset, :settings, required_when_missing: :settings_id)
    iex> EctoShorts.CommonChanges.preload_change_assoc(changeset, :tags, repo: MyApp.CustomRepo)
  """
  @spec preload_change_assoc(changeset(), key(), opts()) :: changeset()
  def preload_change_assoc(changeset, key, opts) do
    required? =
      if opts[:required_when_missing] do
        changeset_field_nil?(changeset, opts[:required_when_missing])
      else
        opts[:required] === true
      end

    opts = Keyword.put(opts, :required, required?)

    if Map.has_key?(changeset.params, Atom.to_string(key)) do
      changeset
      |> preload_changeset_assoc(key, opts)
      |> put_or_cast_assoc(key, opts)
    else
      Changeset.cast_assoc(changeset, key, opts)
    end
  end

  @doc """
  Preloads the specified association onto the changeset `data`
  before calling `put_assoc/3` or `cast_assoc/3`. This is used
  internally by `preload_change_assoc/3` when a key is present
  in the changeset params.

  If the `:ids` option is provided, the association is loaded using
  `Actions.all/3` and matched by those IDs. Otherwise, it uses the
  configured or provided Repo to preload the association.

  ## Options

    * `:ids` - A list of IDs to fetch the associated records directly.
    * `:repo` - An optional custom Repo module to override default repo resolution.

  This is useful when working with nested input data that must be hydrated
  into structs before being validated.
  """
  @spec preload_changeset_assoc(changeset(), key()) :: changeset()
  @spec preload_changeset_assoc(changeset(), key(), opts()) :: changeset()
  def preload_changeset_assoc(changeset, key, opts \\ []) do
    Map.update!(changeset, :data, &Actions.preload(&1, key, opts))
  end

  @doc """
  Determines how to apply an association change based on the shape
  of the input in `changeset.params[key]`.

  This function decides whether to use `put_assoc/4` or `cast_assoc/3`
  depending on what kind of data was passed in. This makes it easier
  to work with many-to-many relationships, nested data, or lists of IDs.

  ## Behavior

    * If given a list of structs, it uses `put_assoc/4`.

    * If given a list of maps with only `:id` fields, it fetches from the DB and replaces the relation.

    * If given a list of maps with new data, it preloads the existing relation and uses `cast_assoc/3`.

    * If given a single struct, it uses `put_assoc/4`.

    * Otherwise, it defaults to `cast_assoc/3`.

  ## Example

      iex> EctoShorts.CommonChanges.put_or_cast_assoc(changeset, :tags)
  """
  @spec put_or_cast_assoc(changeset(), key()) :: changeset()
  @spec put_or_cast_assoc(changeset(), key(), opts()) :: changeset()
  def put_or_cast_assoc(changeset, key, opts \\ []) do
    params_data = Map.get(changeset.params, Atom.to_string(key))

    apply_put_or_cast_assoc(changeset, key, params_data, opts)
  end

  defp apply_put_or_cast_assoc(changeset, key, nil, opts) do
    Changeset.cast_assoc(changeset, key, opts)
  end

  defp apply_put_or_cast_assoc(changeset, key, params_data, opts) when is_list(params_data) do
    schema_module = get_changeset_queryable(changeset)

    cond do
      SchemaIntrospection.all_schema?(params_data) ->
        Changeset.put_assoc(changeset, key, params_data, opts)

      only_primary_keys?(schema_module, params_data) ->
        assoc_schema_module = fetch_association_schema!(changeset, key)

        query_params = prepare_query_params(schema_module, params_data)

        results = Actions.all(assoc_schema_module, query_params, opts)

        Changeset.put_assoc(changeset, key, results, opts)

      SchemaIntrospection.any_created?(schema_module, params_data) ->
        assoc_schema_module = fetch_association_schema!(changeset, key)

        query_params = prepare_query_params(schema_module, params_data)

        results = Actions.all(assoc_schema_module, query_params, opts)

        changeset
        |> Map.update!(:data, fn schema_data ->
          if SchemaIntrospection.association_not_loaded?(schema_data, key) do
            Map.put(schema_data, key, results)
          else
            if opts[:force] === true do
              Map.put(schema_data, key, results)
            else
              EctoShorts.Utils.Logger.warning(
                __MODULE__,
                "Changeset association #{inspect(key)} has loaded data."
              )

              schema_data
            end
          end
        end)
        |> Changeset.cast_assoc(key, opts)

      true ->
        Changeset.cast_assoc(changeset, key, opts)
    end
  end

  defp apply_put_or_cast_assoc(changeset, key, params_data, opts) do
    if SchemaIntrospection.schema?(params_data) do
      Changeset.put_assoc(changeset, key, params_data, opts)
    else
      Changeset.cast_assoc(changeset, key, opts)
    end
  end

  defp prepare_query_params(schema_module, params_data) do
    case SchemaIntrospection.primary_key(schema_module) do
      [_] ->
        schema_module
        |> SchemaIntrospection.filter_primary_keys(params_data)
        |> flatten_query_params()

      _ ->
        %{or_where: SchemaIntrospection.filter_primary_keys(schema_module, params_data)}
    end
  end

  defp flatten_query_params(params_list) do
    Enum.reduce(params_list, %{}, fn params, acc ->
      Enum.reduce(params, acc, fn {key, value}, acc ->
        Map.update(acc, key, [value], &(&1 ++ [value]))
      end)
    end)
  end

  defp only_primary_keys?(schema_module, params_data) do
    Enum.all?(params_data, fn params ->
      SchemaIntrospection.filter_primary_keys(schema_module, params) === params
    end)
  end

  defp fetch_association_schema!(changeset, key) do
    with :ok <- valid_member_of_changeset_types!(changeset, key) do
      changeset
      |> fetch_changeset_assoc_type!(key)
      |> Map.fetch!(:queryable)
    end
  end

  defp valid_member_of_changeset_types!(changeset, key) do
    schema_module = get_changeset_queryable(changeset)

    if member_of_changeset_types?(changeset, key) do
      :ok
    else
      raise KeyError,
            "key not found in schema #{inspect(schema_module)} " <>
            "changeset types, got: #{inspect(key)}"
    end
  end

  defp member_of_changeset_types?(%{types: types}, key) do
    Map.has_key?(types, key)
  end

  defp fetch_changeset_assoc_type!(%{types: types} = changeset, key) do
    schema_module = get_changeset_queryable(changeset)

    case Map.get(types, key) do
      {:assoc, value} ->
        value

      _ ->
        raise KeyError,
              "key not found in schema #{inspect(schema_module)} " <>
                "changeset types, got: #{inspect(key)}"
    end
  end

  defp get_changeset_queryable(%{data: %{__meta__: %{schema: queryable}}}) do
    queryable
  end
end
