defmodule EctoShorts.QueryBuilders.Schema do
  @moduledoc since: "2.5.0"
  @moduledoc """
  Provides a schema-centric implementation of the `EctoShorts.QueryBuilder`
  behaviour for building composable Ecto queries.

  This implementation handles schema-aware filters including joins,
  field-level filtering, and nested selects. It supports filters like:

    * `:join` – Joins associations or subqueries
    * `:select` – Projects specific fields from a schema
    * `:select_merge` – Merges additional fields into a `select` expression
    * `:where` – Filters records by field conditions (AND logic)
    * `:or_where` – Filters records by field conditions using OR logic

  ## Example Usage

      iex> params = %{
      ...>   select: %{name: true, profile: %{age: true}},
      ...>   where: %{active: true}
      ...> }
      iex> query = from(u in User)
      ...> EctoShorts.QueryBuilder.Schema.build_query(query, nil, User, params)

  This will build a query that selects the user's name and profile age,
  and applies a `where` clause to filter for active users.
  """

  alias EctoShorts.{
    CommonSchemas,
    CommonQueryAPI,
    Utils
  }

  @type source :: binary()
  @type query :: Ecto.Query.t()
  @type queryable :: Ecto.Queryable.t()
  @type source_queryable :: {source(), queryable()}
  @type binding_alias :: atom()
  @type binding_key :: atom() | binary()
  @type key :: atom()
  @type value :: any()
  @type params :: map() | keyword()
  @type opts :: keyword()
  @type filter :: :join | :select | :select_merge | :or_where

  @behaviour EctoShorts.QueryBuilder

  @filters ~w(
    join
    select
    select_merge
    or_where
  )a

  @impl EctoShorts.QueryBuilder
  @doc """
  Returns the list of supported filters that can be used in schema-aware queries.

  These filters delegate to `EctoShorts.CommonQueryAPI` and enable dynamic,
  field-driven construction of queries in a composable and reusable way.

  ### Filter behaviors

    * `:join` – Joins an association or subquery into the query. Supports binding aliasing and prefix options.

    * `:select` – Selects fields from the schema or association. Supports nested field selection using maps.

    * `:select_merge` – Adds additional fields to an existing select expression without overwriting previous fields.

    * `:where` – Adds one or more `AND` conditions to the query using field-value pairs or operator tuples.

    * `:or_where` – Adds one or more `OR` conditions, dynamically constructing boolean expressions across fields.

  ## Examples

      iex> EctoShorts.QueryBuilder.Schema.filters()
      [:join, :select, :select_merge, :or_where]
  """
  @spec filters :: [filter()]
  def filters, do: @filters

  @doc """
  Dynamically applies a series of filters to a base Ecto query.

  This function accepts a base query and a map or keyword list of filters,
  and applies them in sequence. Each key in the list must correspond to a
  supported query expression or a schema field/association.

  ## Examples

      iex> params = %{select: %{name: true}, where: %{active: true}}
      ...> EctoShorts.QueryBuilder.Schema.build_query(query, :user, User, params)
  """
  @spec build_query(
          query() | queryable() | source_queryable(),
          binding_alias() | nil,
          queryable(),
          params(),
          opts()
        ) :: query()
  def build_query(query, current_binding, schema_module, params, opts) do
    Enum.reduce(params, query, fn {key, value}, query ->
      build_query(query, current_binding, schema_module, key, value, opts)
    end)
  end

  @impl EctoShorts.QueryBuilder
  @doc """
  Applies a single filter to the query based on a field, association, or supported expression.

  This function determines how to handle the provided filter key:

    * If the key matches a supported filter (e.g., `:select`, `:join`),
      it applies the appropriate query transformation using
      `EctoShorts.CommonQueryAPI`.

    * If the key matches an association in the schema, the query will be
      joined and any nested filters applied to that association.

    * If the key matches a schema field, it applies a standard `where` condition
      with the value or operator/value tuple.

    * If the key is not recognized, it is skipped and a warning is logged.

  ## Examples

      iex> EctoShorts.QueryBuilder.Schema.build_query(query, :user, User, :where, %{active: true})
      iex> EctoShorts.QueryBuilder.Schema.build_query(query, :user, User, :select, %{name: true})

      iex> EctoShorts.QueryBuilder.Schema.build_query(query, :user, User, :where, %{active: true})
      ...> EctoShorts.QueryBuilder.Schema.build_query(query, :user, User, :select, %{name: true})
  """
  @spec build_query(
          query() | queryable() | source_queryable(),
          binding_alias() | nil,
          queryable(),
          key(),
          value(),
          opts()
        ) :: query() | queryable()
  def build_query(query, current_binding, schema_module, key, value, opts) do
    cond do
      query_expression_filter?(key) ->
        build_query_expression(query, current_binding, schema_module, key, value, opts)

      association?(schema_module, key) ->
        build_assoc_filters(query, current_binding, schema_module, key, value, opts)

      query_field?(schema_module, key) ->
        build_schema_filters(query, current_binding, schema_module, key, value, opts)

      true ->
        message = """
        Invalid filter key provided.

        The key you passed is not a valid field or supported query filter for the given schema.

          schema: #{inspect(schema_module)}

          key: #{inspect(key)}

        The query will be unchanged and this key will be skipped.

        To resolve this, you can:

        - Remove the key if it’s unnecessary.

        - Use a supported custom filter, such as:

        #{Enum.map_join(@filters, "\n", &"* #{&1}")}

        - Use a valid schema field, such as:

        #{Enum.map_join(schema_module.__schema__(:query_fields), "\n", &"* #{&1}")}
        """

        assoc_warning_message =
          if schema_module.__schema__(:associations) !== [] do
            """
            - Use a valid association, such as:

            #{Enum.map_join(schema_module.__schema__(:associations), "\n", &"* #{&1}")}
            """
          else
            ""
          end

        EctoShorts.Utils.Logger.warning(__MODULE__, message <> assoc_warning_message)

        query
    end
  end

  defp build_schema_filters(query, current_binding, schema_module, key, value, opts) do
    Utils.apply_expressions(query, value, fn query, value ->
      apply_schema_filter(query, current_binding, schema_module, key, value, opts)
    end)
  end

  defp apply_schema_filter(query, current_binding, schema_module, key, {operator, value}, opts) do
    CommonQueryAPI.where(query, current_binding, schema_module, {key, {operator, value}}, opts)
  end

  defp apply_schema_filter(query, current_binding, schema_module, key, value, opts) do
    apply_schema_filter(query, current_binding, schema_module, key, {:==, value}, opts)
  end

  defp build_query_expression(query, current_binding, schema_module, :join, value, opts) do
    case value do
      {:association, params} ->
        Enum.reduce(params, query, fn {key, value}, query ->
          build_assoc_filters(query, current_binding, schema_module, key, value, opts)
        end)

      {:subquery, params} ->
        build_subquery_filters(query, current_binding, schema_module, params, opts)

      params ->
        Enum.reduce(params, query, fn {key, value}, query ->
          build_query_expression(
            query,
            current_binding,
            schema_module,
            :join,
            {key, value},
            opts
          )
        end)
    end
  end

  defp build_query_expression(query, current_binding, schema_module, :or_where, value, opts) do
    CommonQueryAPI.or_where(query, current_binding, schema_module, value, opts)
  end

  defp build_query_expression(query, current_binding, _schema_module, :select, value, _opts) do
    CommonQueryAPI.select(query, current_binding, value)
  end

  defp build_query_expression(query, current_binding, _schema_module, :select_merge, value, _opts) do
    CommonQueryAPI.select_merge(query, current_binding, value)
  end

  defp build_assoc_filters(query, current_binding, schema_module, key, params, opts) do
    join_association(
      query,
      current_binding,
      schema_module,
      key,
      params,
      fn query, assoc_binding, assoc_schema_module, params ->
        build_query(query, assoc_binding, assoc_schema_module, params, opts)
      end
    )
  end

  defp build_subquery_filters(
         query,
         current_binding,
         schema_module,
         %{from: from} = params,
         opts
       ) do
    join_subquery(
      query,
      current_binding,
      schema_module,
      from,
      params,
      fn query, subquery_binding, subquery_schema_module, params ->
        build_query(query, subquery_binding, subquery_schema_module, params, opts)
      end
    )
  end

  @doc """
  Joins an association on the given key and applies additional
  filters to the joined association.

  This function determines the schema module for the association,
  sets up a named binding for the join, and applies the provided
  filter function (`fun`) to the joined association's queryable,
  binding, and parameters.

  ## Example

      iex> EctoShorts.QueryBuilder.Schema.join_association(
      ...>   query,
      ...>   :user,
      ...>   User,
      ...>   :posts,
      ...>   %{where: %{published: true}},
      ...>   fn query, assoc_binding, assoc_schema_module, params ->
      ...>     build_query(query, assoc_binding, assoc_schema_module, params)
      ...>   end
      ...> )
  """
  @spec join_association(
          query() | queryable() | source_queryable(),
          binding_alias() | nil,
          queryable(),
          key(),
          map() | keyword(),
          function()
        ) :: query()
  def join_association(query, current_binding, schema_module, key, opts, fun) when is_map(opts) do
    join_association(query, current_binding, schema_module, key, Map.to_list(opts), fun)
  end

  def join_association(query, current_binding, schema_module, key, opts, fun) do
    assoc_schema_module = get_association_schema(schema_module, key)

    {assoc_binding, opts} = Keyword.pop(opts, :as)

    assoc_binding = assoc_binding || :"#{named_binding(key)}"

    query
    |> CommonQueryAPI.join({current_binding, assoc_binding}, :association, key, Keyword.take(opts, [:on, :qualifier, :prefix]))
    |> fun.(assoc_binding, assoc_schema_module, opts |> Keyword.drop([:on, :qualifier, :prefix]) |> Map.new())
  end

  @doc """
  Joins a subquery and applies additional filters to it.

  This function extracts the subquery schema module and binding,
  sets up the join, and applies the provided filter function to
  the subquery using the provided parameters.

  ## Example

      iex> EctoShorts.QueryBuilder.Schema.join_subquery(
      ...>   query,
      ...>   :user,
      ...>   User,
      ...>   Post,
      ...>   %{on: ..., where: %{published: true}},
      ...>   fn query, binding, schema, params ->
      ...>     build_query(query, binding, schema, params)
      ...>   end
      ...> )
  """
  @spec join_subquery(
          query() | queryable() | source_queryable(),
          binding_alias() | nil,
          queryable(),
          query() | queryable() | source_queryable(),
          map() | keyword(),
          function()
        ) :: query()
  def join_subquery(query, current_binding, schema_module, from, opts, fun) when is_map(opts) do
    join_subquery(query, current_binding, schema_module, from, Map.to_list(opts), fun)
  end

  def join_subquery(query, current_binding, _schema_module, from, opts, fun) do
    subquery_schema_module = CommonSchemas.get_schema_queryable(from)

    {subquery_binding, opts} = Keyword.pop(opts, :as)

    subquery_binding =
      with nil <- subquery_binding do
        :"#{named_binding_from_module(subquery_schema_module)}"
      end

    join_opts = Keyword.take(opts, [:on, :qualifier, :prefix])

    query
    |> CommonQueryAPI.join(
      {current_binding, subquery_binding},
      :subquery,
      from,
      join_opts
    )
    |> fun.(
      subquery_binding,
      subquery_schema_module,
      opts |> Keyword.drop([:on, :qualifier, :prefix]) |> Map.new()
    )
  end

  @doc """
  Returns the related schema module for a given association.

  Resolves nested `through` associations recursively if necessary.

  ## Example

      iex> EctoShorts.QueryBuilder.Schema.get_association_schema(User, :posts)
      MyApp.Post
  """
  @spec get_association_schema(queryable(), key()) :: queryable()
  def get_association_schema(schema_module, key) do
    case schema_module.__schema__(:association, key) do
      %{through: [field1, field2]} ->
        schema_module
        |> get_association_schema(field1)
        |> get_association_schema(field2)

      %{related: related} ->
        related
    end
  end

  @doc """
  Generates a default named binding string for a given module.

  ## Example

      iex> EctoShorts.QueryBuilder.Schema.named_binding_from_module(MyApp.User)
      "ecto_shorts_user"
  """
  @spec named_binding_from_module(module()) :: binary()
  def named_binding_from_module(module) do
    module
    |> Module.split()
    |> List.last()
    |> Macro.underscore()
    |> named_binding()
  end

  @doc """
  Returns a string that can be used as a named binding in queries.

  ## Example

      iex> EctoShorts.QueryBuilder.Schema.named_binding(:user)
      "ecto_shorts_user"
  """
  @spec named_binding(binding_key()) :: binary()
  def named_binding(key) do
    "ecto_shorts_#{key}"
  end

  defp query_expression_filter?(key) do
    key in @filters
  end

  defp query_field?(schema_module, key) do
    key in schema_module.__schema__(:query_fields)
  end

  defp association?(schema_module, key) do
    key in schema_module.__schema__(:associations)
  end
end
