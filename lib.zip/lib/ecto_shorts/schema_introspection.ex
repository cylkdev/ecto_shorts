defmodule EctoShorts.SchemaIntrospection do
  @type queryable :: Ecto.Queryable.t()
  @type schema_struct :: Ecto.Schema.t()
  @type params :: map()

  def association_loaded?(schema_data, key) do
    not association_not_loaded?(schema_data, key)
  end

  def association_not_loaded?(schema_data, key) do
    case Map.get(schema_data, key) do
      not_loaded when is_struct(not_loaded, Ecto.Association.NotLoaded) -> true
      _ -> false
    end
  end

  @spec all_created?(queryable(), list(schema_struct() | params() | any())) :: boolean()
  def all_created?(schema_module, values), do: Enum.all?(values, &created?(schema_module, &1))

  @spec any_created?(queryable(), list(schema_struct() | params() | any())) :: boolean()
  def any_created?(schema_module, values), do: Enum.any?(values, &created?(schema_module, &1))

  @spec created?(queryable(), schema_struct() | params() | any()) :: boolean()
  def created?(schema_module, data) when is_map(data), do: primary_key?(schema_module, data)
  def created?(_schema_module, _term), do: false

  @spec all_schema?(list(schema_struct() | any())) :: boolean()
  def all_schema?(values), do: Enum.all?(values, &schema?/1)

  @spec any_schema?(list(schema_struct() | any())) :: boolean()
  def any_schema?(values), do: Enum.any?(values, &schema?/1)

  @spec schema?(schema_struct() | any()) :: boolean()
  def schema?(%{__meta__: %{schema: _}}), do: true
  def schema?(_), do: false

  def filter_primary_keys(schema_module, params_list) when is_list(params_list) do
    Enum.map(params_list, &filter_primary_keys(schema_module, &1))
  end

  def filter_primary_keys(schema_module, params) do
    primary_key =
      schema_module
      |> primary_key()
      |> Enum.map(&to_string/1)

    Enum.reduce(params, %{}, fn {key, value}, acc ->
      if to_string(key) in primary_key do
        Map.put(acc, key, value)
      else
        acc
      end
    end)
  end

  @spec all_primary_key?(queryable(), list(params() | schema_struct())) :: boolean()
  def all_primary_key?(schema_module, values) do
    Enum.all?(values, &primary_key?(schema_module, &1))
  end

  @spec any_primary_key?(queryable(), list(params() | schema_struct())) :: boolean()
  def any_primary_key?(schema_module, values) do
    Enum.any?(values, &primary_key?(schema_module, &1))
  end

  @spec primary_key?(Ecto.Queryable.t(), Ecto.Changeset.t() | Ecto.Schema.t() | map()) ::
          boolean()
  def primary_key?(schema_module, %{data: %{__meta__: _} = schema_data}) do
    primary_key?(schema_module, schema_data)
  end

  def primary_key?(schema_module, %{__meta__: _} = schema_data) do
    Enum.all?(schema_module.__schema__(:primary_key), fn key ->
      Map.fetch!(schema_data, key) !== nil
    end)
  end

  def primary_key?(schema_module, params) when is_map(params) do
    primary_keys =
      schema_module
      |> primary_key()
      |> Enum.map(&to_string/1)

    params = Map.new(params, fn {key, value} -> {to_string(key), value} end)

    Enum.all?(primary_keys, fn key ->
      Map.get(params, key) !== nil
    end)
  end

  def primary_key?(_schema_module, _term) do
    false
  end

  def primary_key(schema_module) do
    schema_module.__schema__(:primary_key)
  end
end
