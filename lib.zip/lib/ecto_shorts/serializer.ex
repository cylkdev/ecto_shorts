defmodule EctoShorts.Serializer do
  def to_jsonable_map(%{__meta__: %{schema: queryable}} = struct) do
    struct
    |> Map.from_struct()
    |> Map.drop([:__schema__, :__meta__])
    |> Map.drop(queryable.__schema__(:associations))
  end
end
