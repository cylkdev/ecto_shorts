# Parameterize Function

## Definitions

Use `.agent/DEFINITIONS.md` as the source of truth for definitions used in this repository's standalone documentation system. If a reusable term is missing, add it there instead of defining it locally in this document.

## When to use

Use when any of the following are true:

- Several functions share identical logic except one value.
- Duplicate branches differ only by constant values.
- You want one reusable implementation.

## Problem

Near-identical functions differ only by literals.

```elixir
def five_percent_discount(total), do: total * 0.95

def ten_percent_discount(total), do: total * 0.90
```

## Solution

Create one function with a parameter for the varying part.

```elixir
def discount(total, rate), do: total * (1 - rate)
```

## Why Refactor

- Removes duplication.
- Keeps behaviour changes centralized.
- Makes variation explicit.

## How to Refactor

1. Identify duplicated logic with one varying element.
2. Introduce parameter for variation.
3. Replace duplicates with parameterized function calls.
4. Run formatter and tests.

## Validation

- Duplicate functions are removed or reduced.
- Variation is explicit in parameters.
- Tests pass.

## Eliminates Code Smell

- `Duplicate Code`
