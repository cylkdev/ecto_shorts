# Preserve Whole Struct

## Definitions

Use `.agent/DEFINITIONS.md` as the source of truth for definitions used in this repository's standalone documentation system. If a reusable term is missing, add it there instead of defining it locally in this document.

## When to use

Use when any of the following are true:

- Callers pass several fields from the same struct.
- Function parameters repeatedly unpack one data source.
- The called function may need additional fields later.

## Problem

Field-by-field parameter passing creates noisy signatures.

```elixir
def delivery_window(city, postal_code, country_code), do: ...
```

## Solution

Pass the whole struct/map and extract needed fields inside.

```elixir
def delivery_window(address), do: ...
```

## Why Refactor

- Shortens parameter lists.
- Reduces call-site field plumbing.
- Makes future field needs easier to support.

## How to Refactor

1. Identify parameters that come from one struct.
2. Change signature to receive the whole struct/map.
3. Update call sites.
4. Extract fields inside callee.
5. Run formatter and tests.

## Validation

- Signature is simpler.
- Callers stop passing many sibling fields.
- Tests pass.

## Eliminates Code Smell

- `Long Parameter List`
- `Data Clumps`
