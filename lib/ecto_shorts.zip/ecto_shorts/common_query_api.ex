defmodule EctoShorts.CommonQueryAPI do
  @moduledoc since: "2.5.0"
  @moduledoc """
  `EctoShorts.CommonQueryAPI` provides a standardized API for creating
  `Ecto.Query` expressions with support for bound and unbound contexts.

  This api wraps the `Ecto.Query` macro calls so you don't need to
  import `Ecto.Query` or manually writing macros like `from`, `where`,
  or `select`. You can use maps or keyword lists to drive the behaviour
  of things such as filters, joins, and ordering.

  ## Getting Started

  Here’s a simple example:

      alias EctoShorts.CommonQueryAPI

      EctoShorts.Schemas.Post
      |> CommonQueryAPI.from(as: :post)
      |> CommonQueryAPI.where(:post, %{published: true})
      |> CommonQueryAPI.order_by(:post, [asc: :inserted_at])
      |> CommonQueryAPI.limit(nil, 10)

  You don’t need to `import Ecto.Query`, and there are no macros to
  learn, just use functions that work with data.
  """
  alias Ecto.Query

  alias EctoShorts.{
    CommonQuery,
    DynamicExpressions,
    Utils
  }

  require Ecto.Query

  @type changeset :: Ecto.Changeset.t()
  @type dynamic_expr :: %Ecto.Query.DynamicExpr{}
  @type subquery :: Ecto.SubQuery.t()
  @type query :: Ecto.Query.t()
  @type schema :: Ecto.Queryable.t()
  @type source :: binary()
  @type schema_source :: {source(), schema()}
  @type schema_metadata :: Ecto.Schema.Metadata.t()
  @type schema_input :: schema() | schema_source()
  @type query_source :: query() | schema_input()
  @type prefix :: binary() | nil
  @type binding_alias :: atom() | nil
  @type condition :: :and | :or
  @type join_operation :: :association | :subquery | :query
  @type limit :: non_neg_integer()
  @type offset :: integer()
  @type key :: atom()
  @type value :: any()
  @type operator :: atom()
  @type params :: map() | keyword()
  @type opts :: keyword()

  # @doc """
  # Merges two dynamic expressions with `and`.

  # Returns the second expression if the first is `nil`.
  # """
  # def merge_dynamic(_, nil, _, dyn_b) do
  #   dyn_b
  # end

  # def merge_dynamic(:and, dyn_a, binding_alias, dyn_b) do
  #   if binding_alias !== nil do
  #     Query.dynamic([{^binding_alias, q}], ^dyn_a and ^dyn_b)
  #   else
  #     Query.dynamic([q], ^dyn_a and ^dyn_b)
  #   end
  # end

  # def merge_dynamic(:or, dyn_a, binding_alias, dyn_b) do
  #   if binding_alias !== nil do
  #     Query.dynamic([{^binding_alias, q}], ^dyn_a or ^dyn_b)
  #   else
  #     Query.dynamic([q], ^dyn_a or ^dyn_b)
  #   end
  # end

  # @doc """
  # Builds a binding-aware dynamic expression.

  # If a binding is provided, the dynamic will be created using that named binding.
  # If no binding is given, it defaults to the root from binding.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.dynamic(nil, id: 1)
  # """
  # def dynamic(binding_alias, true) do
  #   IO.inspect(binding(), label: "YES")

  #   if binding_alias !== nil do
  #     Query.dynamic([{^binding_alias, q}], true)
  #   else
  #     Query.dynamic([q], true)
  #   end
  # end

  # # ---

  # def dynamic(binding_alias, value) do
  #   IO.inspect(binding(), label: "YES")

  #   if binding_alias !== nil do
  #     Query.dynamic([{^binding_alias, q}], ^value)
  #   else
  #     Query.dynamic([q], ^value)
  #   end
  # end

  # # @doc """
  # # Sets the `from` clause on a query.
  # # """
  # # def from(query, binding_alias \\ nil, opts \\ [])

  # # def from(query, binding_alias, opts) when is_map(opts) do
  # #   from(query, binding_alias, Map.to_list(opts))
  # # end

  # # def from(query, binding_alias, opts) do
  # #   prefix = opts[:prefix]

  # #   if binding_alias !== nil do
  # #     query
  # #     |> Query.from(as: ^binding_alias, prefix: ^prefix)
  # #     |> maybe_put_query_prefix(opts)
  # #   else
  # #     query
  # #     |> Query.from(prefix: ^prefix)
  # #     |> maybe_put_query_prefix(opts)
  # #   end
  # # end

  # # defp maybe_put_query_prefix(query, opts) do
  # #   case opts[:query_prefix] do
  # #     nil -> query
  # #     prefix -> put_query_prefix(query, prefix)
  # #   end
  # # end

  # @doc """
  # Overrides the query’s schema prefix (useful for multi-tenancy).

  # ## Example

  #     iex> import Ecto.Query
  #     ...> query = from p in EctoShorts.Schemas.Post
  #     ...> query = EctoShorts.CommonQueryAPI.put_query_prefix(query, "tenant_123")
  #     ...> query.prefix
  #     "tenant_123"
  # """
  # @spec put_query_prefix(query_source(), prefix()) :: query()
  # def put_query_prefix(query, prefix) do
  #   Query.put_query_prefix(query, prefix)
  # end

  # @doc """
  # Wraps a query as a subquery.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.subquery(EctoShorts.Schemas.Post)
  # """
  # @spec subquery(query_source() | subquery()) :: subquery()
  # @spec subquery(query_source() | subquery(), opts()) :: subquery()
  # def subquery(query, opts \\ []) do
  #   Query.subquery(query, opts)
  # end

  # @doc """
  # Excludes a field (such as `:order_by`) from the query.

  # ## Examples

  #     iex> import Ecto.Query
  #     ...> query = from p in EctoShorts.Schemas.Post, order_by: p.inserted_at
  #     ...> EctoShorts.CommonQueryAPI.exclude(query, :order_by)
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post>
  # """
  # @spec exclude(query_source(), key()) :: query()
  # def exclude(query, key) do
  #   Query.exclude(query, key)
  # end

  # @doc """
  # Limits the number of results returned by the query.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.limit(EctoShorts.Schemas.Post, nil, 10)
  # """
  # def limit(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.limit(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.limit(query, [q], ^value)
  #   end
  # end

  # @doc """
  # Offsets the results returned by the query.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.offset(EctoShorts.Schemas.Post, nil, 20)
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, offset: ^20>
  # """
  # def offset(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.offset(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.offset(query, [q], ^value)
  #   end
  # end

  # @doc """
  # Groups the results by the given value.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.group_by(EctoShorts.Schemas.Post, nil, :id)
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, group_by: [p0.id]>
  # """
  # def group_by(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.group_by(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.group_by(query, [q], ^value)
  #   end
  # end

  # @doc """
  # Orders the results by the given value.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.order_by(EctoShorts.Schemas.Post, nil, [asc: :inserted_at])
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, order_by: [asc: p0.inserted_at]>
  # """

  # def order_by(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.order_by(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.order_by(query, [q], ^value)
  #   end
  # end

  # @doc """
  # Preloads associations on the query.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.preload(EctoShorts.Schemas.Post, nil, :comments)
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, preload: [:comments]>
  # """
  # def preload(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.preload(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.preload(query, [q], ^value)
  #   end
  # end

  # @doc """
  # ...
  # """
  # def select(query, binding_alias, true) do
  #   query_select(query, binding_alias, true)
  # end

  # def select(query, binding_alias, values) when is_list(values) do
  #   if Keyword.keyword?(values) do
  #     select(query, binding_alias, Map.new(values))
  #   else
  #     query_select(query, binding_alias, {:map, values})
  #   end
  # end

  # def select(query, binding_alias, params) do
  #   if Map.has_key?(params, :expression) do
  #     query_select(query, binding_alias, params[:expression])
  #   else
  #     Utils.apply_expressions(
  #       query,
  #       params,
  #       fn {key, value}, query ->
  #         query_select(query, binding_alias, {key, value})
  #       end
  #     )
  #   end
  # end

  # # ---
  # defp query_select(query, binding_alias, {:map, values}) do
  #   if binding_alias !== nil do
  #     Query.select(query, [{^binding_alias, q}], map(q, ^values))
  #   else
  #     Query.select(query, [q], map(q, ^values))
  #   end
  # end

  # # ---

  # defp query_select(query, binding_alias, {:struct, values}) do
  #   if binding_alias !== nil do
  #     Query.select(query, [{^binding_alias, q}], struct(q, ^values))
  #   else
  #     Query.select(query, [q], struct(q, ^values))
  #   end
  # end

  # # ---

  # defp query_select(query, binding_alias, true) do
  #   if binding_alias !== nil do
  #     Query.select(query, [{^binding_alias, q}], q)
  #   else
  #     Query.select(query, [q], q)
  #   end
  # end

  # # ---

  # defp query_select(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.select(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.select(query, [q], ^value)
  #   end
  # end

  # @doc """
  # ...
  # """
  # def select_merge(query, binding_alias, values) when is_list(values) do
  #   if Keyword.keyword?(values) do
  #     select_merge(query, binding_alias, Map.new(values))
  #   else
  #     query_select_merge(query, binding_alias, values)
  #   end
  # end

  # def select_merge(query, binding_alias, params) when is_map(params) do
  #   if Map.has_key?(params, :expression) do
  #     query_select_merge(query, binding_alias, params[:expression])
  #   else
  #     Utils.apply_expressions(query, params, fn {key, value}, query ->
  #       query_select_merge(query, binding_alias, {key, value})
  #     end)
  #   end
  # end

  # def select_merge(query, binding_alias, value) do
  #   query_select_merge(query, binding_alias, value)
  # end

  # # ---

  # defp query_select_merge(query, binding_alias, {:map, keys}) do
  #   if binding_alias !== nil do
  #     Query.select_merge(query, [{^binding_alias, q}], map(q, ^keys))
  #   else
  #     Query.select_merge(query, [q], map(q, ^keys))
  #   end
  # end

  # # ---

  # defp query_select_merge(query, binding_alias, {:struct, keys}) do
  #   if binding_alias !== nil do
  #     Query.select_merge(query, [{^binding_alias, q}], struct(q, ^keys))
  #   else
  #     Query.select_merge(query, [q], struct(q, ^keys))
  #   end
  # end

  # # ---

  # defp query_select_merge(query, binding_alias, true) do
  #   if binding_alias !== nil do
  #     Query.select_merge(query, [{^binding_alias, q}], q)
  #   else
  #     Query.select_merge(query, [q], q)
  #   end
  # end

  # # ---

  # defp query_select_merge(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.select_merge(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.select_merge(query, [q], ^value)
  #   end
  # end

  # @doc """
  # Adds a join to the query for an association or subquery.

  # ## Examples

  #     iex> EctoShorts.CommonQueryAPI.join(EctoShorts.Schemas.Post, :association, nil, :comments)
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, join: c1 in assoc(p0, :comments)>

  #     iex> EctoShorts.CommonQueryAPI.join(EctoShorts.Schemas.Post, :association, nil, :comments, as: :comments)
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, join: c1 in assoc(p0, :comments), as: :comments>

  #     iex> EctoShorts.CommonQueryAPI.join(EctoShorts.Schemas.Post, :association, nil, :comments, %{as: :comments, on: %{id: 2}})
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, join: c1 in assoc(p0, :comments), as: :comments, on: c1.id == ^2>

  #     iex> EctoShorts.CommonQueryAPI.join(EctoShorts.Schemas.Post, :association, nil, :comments, %{as: :comments, on: %{id: %{>=: 2}}})
  #     #Ecto.Query<from p0 in EctoShorts.Schemas.Post, join: c1 in assoc(p0, :comments), as: :comments, on: c1.id >= ^2>
  # """
  # def join(query, type, binding_alias, key, params \\ %{}, opts \\ [])

  # def join(query, type, binding_alias, key, params, opts) when is_list(params) do
  #   join(query, type, binding_alias, key, Map.new(params), opts)
  # end

  # def join(query, :association, binding_alias, key, params, opts) do
  #   binding_alias = binding_alias
  #   as = params[:as]
  #   qual = params[:qualifier] || :inner
  #   prefix = params[:prefix]

  #   on = create_dynamic(query, binding_alias, as, params[:on] || true, opts)

  #   join_association(query, binding_alias, as, key, qual, on, prefix)
  # end

  # def join(query, :subquery, binding_alias, inner_query, params, opts) do
  #   binding_alias = binding_alias
  #   as = params[:as]
  #   qual = params[:qualifier] || :inner
  #   prefix = params[:prefix]
  #   on = create_dynamic(query, binding_alias, as, params[:on] || true, opts)

  #   join_subquery(
  #     query,
  #     binding_alias,
  #     as,
  #     inner_query,
  #     qual,
  #     on,
  #     prefix
  #   )
  # end

  # def join(query, :query, binding_alias, source, params, opts) do
  #   binding_alias = binding_alias
  #   as = params[:as]
  #   qual = params[:qualifier] || :inner
  #   prefix = params[:prefix]

  #   on = create_dynamic(query, binding_alias, as, params[:on] || true, opts)

  #   join_query(query, as, source, qual, on, prefix)
  # end

  # # ---

  # defp join_association(query, {:position, pos}, as, key, qual, on, prefix) do
  #   case pos do
  #     :first ->
  #       if as !== nil do
  #         Query.join(
  #           query,
  #           qual,
  #           [q],
  #           assoc(q, ^key),
  #           as: ^as,
  #           on: ^on,
  #           prefix: ^prefix
  #         )
  #       else
  #         Query.join(
  #           query,
  #           qual,
  #           [q],
  #           assoc(q, ^key),
  #           on: ^on,
  #           prefix: ^prefix
  #         )
  #       end

  #     :last ->
  #       if as !== nil do
  #         Query.join(
  #           query,
  #           qual,
  #           [_, ..., q],
  #           assoc(q, ^key),
  #           as: ^as,
  #           on: ^on,
  #           prefix: ^prefix
  #         )
  #       else
  #         Query.join(
  #           query,
  #           qual,
  #           [_, ..., q],
  #           assoc(q, ^key),
  #           on: ^on,
  #           prefix: ^prefix
  #         )
  #       end
  #   end
  # end

  # defp join_association(query, binding_alias, as, key, qual, on, prefix) do
  #   if binding_alias !== nil do
  #     if as !== nil do
  #       Query.with_named_binding(query, as, fn query, as ->
  #         Query.join(
  #           query,
  #           qual,
  #           [{^binding_alias, q}],
  #           assoc(q, ^key),
  #           as: ^as,
  #           on: ^on,
  #           prefix: ^prefix
  #         )
  #       end)
  #     else
  #       Query.join(
  #         query,
  #         qual,
  #         [{^binding_alias, q}],
  #         assoc(q, ^key),
  #         on: ^on,
  #         prefix: ^prefix
  #       )
  #     end
  #   else
  #     if as !== nil do
  #       Query.with_named_binding(query, as, fn query, as ->
  #         Query.join(
  #           query,
  #           qual,
  #           [q],
  #           assoc(q, ^key),
  #           as: ^as,
  #           on: ^on,
  #           prefix: ^prefix
  #         )
  #       end)
  #     else
  #       Query.join(
  #         query,
  #         qual,
  #         [q],
  #         assoc(q, ^key),
  #         on: ^on,
  #         prefix: ^prefix
  #       )
  #     end
  #   end
  # end

  # # ---

  # defp join_subquery(query, {:position, :first}, as, inner_query, qual, on, prefix) do
  #   if as !== nil do
  #     Query.join(
  #       query,
  #       qual,
  #       [q],
  #       subquery(inner_query),
  #       as: ^as,
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   else
  #     Query.join(
  #       query,
  #       qual,
  #       [q],
  #       subquery(inner_query),
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   end
  # end

  # defp join_subquery(query, {:position, :last}, as, inner_query, qual, on, prefix) do
  #   if as !== nil do
  #     Query.join(
  #       query,
  #       qual,
  #       [_, ..., q],
  #       subquery(inner_query),
  #       as: ^as,
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   else
  #     Query.join(
  #       query,
  #       qual,
  #       [_, ..., q],
  #       subquery(inner_query),
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   end
  # end

  # defp join_subquery(query, binding_alias, nil, inner_query, qual, on, prefix) do
  #   if binding_alias !== nil do
  #     Query.join(
  #       query,
  #       qual,
  #       [{^binding_alias, q}],
  #       subquery(inner_query),
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   else
  #     Query.join(
  #       query,
  #       qual,
  #       [q],
  #       subquery(inner_query),
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   end
  # end

  # defp join_subquery(query, binding_alias, as, inner_query, qual, on, prefix) do
  #   if binding_alias !== nil do
  #     Query.join(
  #       query,
  #       qual,
  #       [{^binding_alias, q}],
  #       subquery(inner_query),
  #       as: ^as,
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   else
  #     Query.join(
  #       query,
  #       qual,
  #       [q],
  #       subquery(inner_query),
  #       as: ^as,
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   end
  # end

  # # ---

  # defp join_query(query, as, source, qual, on, prefix) do
  #   source = normalize_source(source)

  #   if as !== nil do
  #     Query.join(
  #       query,
  #       qual,
  #       [q],
  #       ^source,
  #       as: ^as,
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   else
  #     Query.join(
  #       query,
  #       qual,
  #       [q],
  #       ^source,
  #       on: ^on,
  #       prefix: ^prefix
  #     )
  #   end
  # end

  # def or_where(query, binding_alias, values, opts \\ [])

  # def or_where(query, binding_alias, values, opts) when is_list(values) do
  #   if Keyword.keyword?(values) do
  #     or_where(query, binding_alias, Map.new(values), opts)
  #   else
  #     Enum.reduce(values, query, fn value, query ->
  #       or_where(query, binding_alias, value, opts)
  #     end)
  #   end
  # end

  # def or_where(query, binding_alias, params, opts) do
  #   if Map.has_key?(params, :expression) do
  #     query_or_where(query, binding_alias, params.expression)
  #   else
  #     expr =
  #       if Map.has_key?(params, :expression) do
  #         params.expression
  #       else
  #         create_dynamic(query, binding_alias, nil, params, opts)
  #       end

  #     query_or_where(query, nil, expr)
  #   end
  # end

  # defp query_or_where(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.or_where(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.or_where(query, [q], ^value)
  #   end
  # end

  # def where(query, binding_alias, values, opts \\ [])

  # def where(query, binding_alias, values, opts) when is_list(values) do
  #   if Keyword.keyword?(values) do
  #     where(query, binding_alias, Map.new(values), opts)
  #   else
  #     Enum.reduce(values, query, fn value, query ->
  #       where(query, binding_alias, value, opts)
  #     end)
  #   end
  # end

  # def where(query, binding_alias, params, opts) do
  #   expr =
  #     if Map.has_key?(params, :expression) do
  #       params.expression
  #     else
  #       create_dynamic(query, binding_alias, nil, params, opts)
  #     end

  #   query_where(query, nil, expr)
  # end

  # defp query_where(query, binding_alias, value) do
  #   if binding_alias !== nil do
  #     Query.where(query, [{^binding_alias, q}], ^value)
  #   else
  #     Query.where(query, [q], ^value)
  #   end
  # end

  # defp create_dynamic(query, parent_binding_alias, target_binding, value, opts) do
  #   case value do
  #     true ->
  #       query
  #       |> CommonQuery.lookup_binding_expr_source(parent_binding_alias)
  #       |> DynamicExpressions.convert_to_dynamic(target_binding, true, opts)

  #     params ->
  #       query
  #       |> get_source(parent_binding_alias, params)
  #       |> DynamicExpressions.convert_to_dynamic(target_binding, params, opts)
  #   end
  # end

  # defp get_source(query, binding_alias, params) do
  #   cond do
  #     Map.has_key?(params, :source) and Map.has_key?(params, :schema) ->
  #       {params.source, params.schema}

  #     Map.has_key?(params, :source) ->
  #       params.source

  #     true ->
  #       CommonQuery.lookup_binding_expr_source(query, binding_alias)
  #   end
  # end

  # defp normalize_source({nil, schema}) when is_atom(schema) do
  #   schema
  # end

  # defp normalize_source({source, schema}) when is_atom(schema) do
  #   {source, schema}
  # end

  # defp normalize_source(source) when is_binary(source) do
  #   source
  # end
end
