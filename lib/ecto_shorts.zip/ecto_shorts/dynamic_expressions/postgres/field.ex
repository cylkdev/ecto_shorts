defmodule EctoShorts.DynamicExpressions.Postgres.Field do
  @moduledoc since: "2.5.0"
  @moduledoc """
  Provides dynamic filter expressions for scalar fields in Postgres.

  This module builds `Ecto.Query.dynamic/2` expressions for a wide
  range of field-level operators, including equality, inequality,
  pattern matching, comparison, and case transformations.

  It's designed to be used internally by dynamic filtering modules
  to simplify runtime filter generation based on user-provided or
  derived parameters.

  All expressions are safe for composition in dynamic queries and
  handle optional query binding aliases.

  ## Supported operators

    * `:==`, `:!=` — for equality and inequality
    * `:<`, `:<=`, `:>`, `:>=` — for comparison
    * `:like`, `:ilike`, `:=~` — for pattern matching
    * Special support for case-based comparison: `{:lower, val}`, `{:upper, val}`
    * List values: translated to `IN (...)` or `NOT IN (...)`
    * `nil` values: translated to `IS NULL` or `IS NOT NULL`
  """

  alias Ecto.Query

  require Ecto.Query

  @type dynamic_expr :: Ecto.Query.dynamic_expr()
  @type binding_alias :: atom() | nil
  @type operator :: atom()

  @doc """
  Builds a dynamic query expression for a single scalar
  field using a given operator and value.

  Supports conditional behavior depending on the value type
  (e.g., `nil`, list, case-modified), and gracefully handles
  both named bindings (`as: :alias`) and positional bindings.

  This function is typically used by higher-level dynamic
  filtering modules, like `EctoShorts.DynamicExpressions.Postgres`,
  to generate `where` and `or_where` clauses dynamically.
  """
  @spec build_dynamic(binding_alias() | nil, any(), operator(), any()) :: dynamic_expr()
  def build_dynamic(binding_alias, key, :eq, value),
    do: build_dynamic(binding_alias, key, :==, value)

  def build_dynamic(binding_alias, key, :not, value),
    do: build_dynamic(binding_alias, key, :!=, value)

  def build_dynamic(binding_alias, key, :lt, value),
    do: build_dynamic(binding_alias, key, :<, value)

  def build_dynamic(binding_alias, key, :gt, value),
    do: build_dynamic(binding_alias, key, :>, value)

  def build_dynamic(binding_alias, key, :lte, value),
    do: build_dynamic(binding_alias, key, :<=, value)

  def build_dynamic(binding_alias, key, :gte, value),
    do: build_dynamic(binding_alias, key, :>=, value)

  # ---

  def build_dynamic(binding_alias, key, :ilike, values) when is_list(values) do
    patterns = Enum.map(values, &"%#{&1}%")

    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("? ILIKE ANY(SELECT unnest(?))", field(q, ^key), ^patterns)
      )
    else
      Query.dynamic(
        [q],
        fragment("? ILIKE ANY(SELECT unnest(?))", field(q, ^key), ^patterns)
      )
    end
  end

  def build_dynamic(binding_alias, key, :ilike, value) do
    pattern = "%#{value}%"

    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], ilike(field(q, ^key), ^pattern))
    else
      Query.dynamic([q], ilike(field(q, ^key), ^pattern))
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :like, values) when is_list(values) do
    patterns = Enum.map(values, &"%#{&1}%")

    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("? LIKE ANY(SELECT unnest(?))", field(q, ^key), ^patterns)
      )
    else
      Query.dynamic(
        [q],
        fragment("? LIKE ANY(SELECT unnest(?))", field(q, ^key), ^patterns)
      )
    end
  end

  def build_dynamic(binding_alias, key, :like, value) do
    pattern = "%#{value}%"

    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], like(field(q, ^key), ^pattern))
    else
      Query.dynamic([q], like(field(q, ^key), ^pattern))
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :=~, values) when is_list(values) do
    Enum.reduce(values, nil, fn value, dyn_a ->
      or_dynamic(binding_alias, dyn_a, build_dynamic(binding_alias, key, :=~, value))
    end)
  end

  def build_dynamic(binding_alias, key, :=~, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("? ~* ?", field(q, ^key), ^value))
    else
      Query.dynamic([q], fragment("? ~* ?", field(q, ^key), ^value))
    end
    |> dbg()
  end

  # ---

  def build_dynamic(binding_alias, key, :<, values) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("? < ANY(?)", field(q, ^key), ^values))
    else
      Query.dynamic([q], fragment("? < ANY(?)", field(q, ^key), ^values))
    end
  end

  def build_dynamic(binding_alias, key, :<, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) < ^value)
    else
      Query.dynamic([q], field(q, ^key) < ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :>, values) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("? > ANY(?)", field(q, ^key), ^values))
    else
      Query.dynamic([q], fragment("? > ANY(?)", field(q, ^key), ^values))
    end
  end

  def build_dynamic(binding_alias, key, :>, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) > ^value)
    else
      Query.dynamic([q], field(q, ^key) > ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :<=, values) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("? <= ANY(?)", field(q, ^key), ^values))
    else
      Query.dynamic([q], fragment("? <= ANY(?)", field(q, ^key), ^values))
    end
  end

  def build_dynamic(binding_alias, key, :<=, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) <= ^value)
    else
      Query.dynamic([q], field(q, ^key) <= ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :>=, values) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("? >= ANY(?)", field(q, ^key), ^values))
    else
      Query.dynamic([q], fragment("? >= ANY(?)", field(q, ^key), ^values))
    end
  end

  def build_dynamic(binding_alias, key, :>=, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) >= ^value)
    else
      Query.dynamic([q], field(q, ^key) >= ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :!=, {:lower, values}) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("LOWER(?)", field(q, ^key)) not in ^values
      )
    else
      Query.dynamic([q], fragment("LOWER(?)", field(q, ^key)) not in ^values)
    end
  end

  def build_dynamic(binding_alias, key, :!=, {:lower, value}) do
    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("LOWER(?)", field(q, ^key)) != ^value
      )
    else
      Query.dynamic([q], fragment("LOWER(?)", field(q, ^key)) != ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :!=, {:upper, values}) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("UPPER(?)", field(q, ^key)) not in ^values
      )
    else
      Query.dynamic([q], fragment("UPPER(?)", field(q, ^key)) not in ^values)
    end
  end

  def build_dynamic(binding_alias, key, :!=, {:upper, value}) do
    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("UPPER(?)", field(q, ^key)) != ^value
      )
    else
      Query.dynamic([q], fragment("UPPER(?)", field(q, ^key)) != ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :!=, nil) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], not is_nil(field(q, ^key)))
    else
      Query.dynamic([q], not is_nil(field(q, ^key)))
    end
  end

  def build_dynamic(binding_alias, key, :!=, values) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) not in ^values)
    else
      Query.dynamic([q], field(q, ^key) not in ^values)
    end
  end

  def build_dynamic(binding_alias, key, :!=, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) != ^value)
    else
      Query.dynamic([q], field(q, ^key) != ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :==, {:lower, values}) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("LOWER(?)", field(q, ^key)) in ^values)
    else
      Query.dynamic([q], fragment("LOWER(?)", field(q, ^key)) in ^values)
    end
  end

  def build_dynamic(binding_alias, key, :==, {:lower, value}) do
    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("LOWER(?)", field(q, ^key)) == ^value
      )
    else
      Query.dynamic([q], fragment("LOWER(?)", field(q, ^key)) == ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :==, {:upper, values}) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], fragment("UPPER(?)", field(q, ^key)) in ^values)
    else
      Query.dynamic([q], fragment("UPPER(?)", field(q, ^key)) in ^values)
    end
  end

  def build_dynamic(binding_alias, key, :==, {:upper, value}) do
    if binding_alias !== nil do
      Query.dynamic(
        [{^binding_alias, q}],
        fragment("UPPER(?)", field(q, ^key)) == ^value
      )
    else
      Query.dynamic([q], fragment("UPPER(?)", field(q, ^key)) == ^value)
    end
  end

  # ---

  def build_dynamic(binding_alias, key, :==, nil) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], is_nil(field(q, ^key)))
    else
      Query.dynamic([q], is_nil(field(q, ^key)))
    end
  end

  def build_dynamic(binding_alias, key, :==, values) when is_list(values) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) in ^values)
    else
      Query.dynamic([q], field(q, ^key) in ^values)
    end
  end

  def build_dynamic({:position, :first}, key, :==, value) do
    Query.dynamic([q], field(q, ^key) == ^value)
  end

  def build_dynamic({:position, :last}, key, :==, value) do
    Query.dynamic([_, ..., q], field(q, ^key) == ^value)
  end

  def build_dynamic(binding_alias, key, :==, value) do
    if binding_alias !== nil do
      Query.dynamic([{^binding_alias, q}], field(q, ^key) == ^value)
    else
      Query.dynamic([q], field(q, ^key) == ^value)
    end
  end

  defp or_dynamic(_binding_alias, nil, dyn_b), do: dyn_b

  defp or_dynamic(binding_alias, dyn_a, dyn_b) do
    if binding_alias !== nil do
      Query.dynamic([{binding_alias, d}], ^dyn_a or ^dyn_b)
    else
      Query.dynamic([q], ^dyn_a or ^dyn_b)
    end
  end
end
