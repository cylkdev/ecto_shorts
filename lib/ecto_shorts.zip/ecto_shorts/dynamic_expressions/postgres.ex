defmodule EctoShorts.DynamicExpressions.Postgres do
  @moduledoc since: "2.5.0"
  @moduledoc """
  Build dynamic `where` and `or_where` filters for Postgres without
  writing raw `Ecto.Query` expressions.

  This module makes it easier to add dynamic filters to your Ecto
  queries, especially when the filters come from user input or need
  to change at runtime.

  Instead of writing out each con manually, you can pass in a
  map or keyword list of filters. It handles building the right
  expressions for each field based on its type—so you don’t need to
  worry about whether a field is a string, number, or array.
  """

  alias EctoShorts.{
    CommonQueryAPI,
    DynamicExpressions.Postgres.Array,
    DynamicExpressions.Postgres.Field,
    SchemaHelpers,
    Utils
  }

  @behaviour EctoShorts.DynamicExpression

  @type schema :: Ecto.Queryable.t()
  @type dynamic_expr :: %Ecto.Query.DynamicExpr{}
  @type maybe_dynamic_expr :: dynamic_expr() | nil
  @type binding_alias :: atom() | nil

  @type con :: :and | :or

  @type key :: atom()
  @type value :: any()
  @type operator :: any()
  @type params :: map()

  @sql_string_match_operators ~w(like ilike)a
  @symbolic_comparison_operators ~w(=~ == != < > <= >=)a
  @named_comparison_operator_aliases ~w(re eq not lt gt lte gte)a

  @operators @sql_string_match_operators ++
               @symbolic_comparison_operators ++ @named_comparison_operator_aliases

  @conditions [:and, :or]

  @doc false
  def operators, do: @operators

  @impl EctoShorts.DynamicExpression
  @doc """
  Builds a dynamic expression for a single filter con
  using the given field, operator, and value.

  This function is the core of dynamic filter generation.
  It inspects the field type in the schema to determine
  whether to apply a standard field con or handle it
  as an array-based con.

  Depending on whether the field is a normal scalar or an
  array, it delegates to the appropriate module (`Field` or
  `Array`) and then merges the resulting expression into the
  provided dynamic expression.

  ## Parameters

    * `schema` – the Ecto schema module used for field introspection.
    * `dyn` – the existing dynamic expression (or `nil`) to be merged into.
    * `binding_alias` – an optional binding alias for use in the dynamic clause.
    * `con` – the logical operator used to combine expressions (`:and` or `:or`).
    * `key` – the field name being filtered on.
    * `value` – The value used for the operation, typically a tuple of `{operator, value}`
      representing the operator (e.g. `:==`, `:ilike`, `:in`) and its value.
  """
  def build_dynamic(_source, binding_alias, true) do
    CommonQueryAPI.dynamic(binding_alias, true)
  end

  def build_dynamic(source, binding_alias, params) do
    with nil <- reduce_params(source, binding_alias, params) do
      CommonQueryAPI.dynamic(binding_alias, true)
    end
  end

  defp reduce_params(source, binding_alias, params) do
    Utils.apply_expressions(nil, params, fn {key, value}, dyn ->
      reduce_params(source, dyn, binding_alias, key, value, {:and, :==})
    end)
  end

  defp reduce_params(source, dyn, binding_alias, condition, {key, value}, {_, operator})
       when condition in @conditions do
    reduce_params(source, dyn, binding_alias, key, value, {condition, operator})
  end

  defp reduce_params(source, dyn, binding_alias, key, {condition, value}, {_, operator})
       when condition in @conditions do
    reduce_params(source, dyn, binding_alias, key, value, {condition, operator})
  end

  defp reduce_params(source, dyn, binding_alias, operator, {key, value}, {condition, _})
       when operator in @operators do
    reduce_params(source, dyn, binding_alias, key, value, {condition, operator})
  end

  defp reduce_params(source, dyn, binding_alias, key, {operator, value}, {condition, _})
       when operator in @operators do
    reduce_params(source, dyn, binding_alias, key, value, {condition, operator})
  end

  defp reduce_params(source, dyn, binding_alias, key, value, {condition, operator}) do
    build_dynamic_expr(source, dyn, binding_alias, condition, key, operator, value)
  end

  @doc false
  def build_dynamic_expr(source, dyn, binding_alias, condition, key, operator, value) do
    IO.inspect(binding(), label: "FOOO")

    expr =
      if SchemaHelpers.schema_source?(source) and field_type_array?(source, key) do
        if list?(value) do
          IO.inspect("1")
          Array.build_dynamic(binding_alias, key, operator, value)
        else
          IO.inspect("2")
          Array.build_dynamic(binding_alias, value, operator, key)
        end
      else
        IO.inspect("3")
        Field.build_dynamic(binding_alias, key, operator, value)
      end

    IO.inspect("4")

    CommonQueryAPI.merge_dynamic(condition, dyn, binding_alias, expr)
  end

  defp list?({_, value}) when is_list(value), do: true
  defp list?(value) when is_list(value), do: true
  defp list?(_), do: false

  defp field_type_array?(source, key) do
    source
    |> schema_from_source()
    |> SchemaHelpers.field_type_array?(key)
  end

  defp schema_from_source({_, schema}), do: schema
  defp schema_from_source(schema), do: schema
end
