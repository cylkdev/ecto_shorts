defmodule EctoShorts.DynamicExpressions do
  @moduledoc since: "2.5.0"
  @moduledoc """
  Dynamic expressions in `EctoShorts` provide a flexible adapter aware
  way to build Ecto query dynamic expressions. These dynamic expressions
  are typically used to construct `where` and `or_where` filters without
  requiring users to manually write `Ecto.Query.dynamic/2` code.

  ## Adapter Support

  The dynamic expressions API is designed to be adapter-aware, with each
  adapter implementing the `EctoShorts.DynamicExpression` behaviour. This
  allows each adapter to account for its own syntax, capabilities, and
  idioms.

  ### Currently Supported Adapters

    - `EctoShorts.DynamicExpressions.Postgres` - Supports building dynamic
      expressions when using `Ecto.Adapters.Postgres`.

  Additional adapter modules can be added in the future by implementing the
  `EctoShorts.DynamicExpression` behaviour.

  See `EctoShorts.DynamicExpression` for information on creating your own
  adapter.
  """

  alias EctoShorts.Config
  alias EctoShorts.DynamicExpression

  @type schema :: Ecto.Queryable.t()
  @type dynamic_expr :: %Ecto.Query.DynamicExpr{}
  @type maybe_dynamic_expr :: dynamic_expr() | nil
  @type binding_alias :: atom() | nil
  @type condition :: :and | :or
  @type key :: atom()
  @type value :: any()
  @type opts :: keyword()

  @adapters %{
    Ecto.Adapters.Postgres => EctoShorts.DynamicExpressions.Postgres
  }

  @doc false
  def adapters, do: @adapters

  def convert_to_dynamic(source, binding_alias, input, opts) do
    opts
    |> adapter!()
    |> DynamicExpression.build_dynamic(source, binding_alias, input)
  end

  defp adapter!(opts) do
    if Keyword.has_key?(opts, :dynamic_expression_adapter) do
      opts[:dynamic_expression_adapter]
    else
      adapter_for_repo!(opts)
    end
  end

  defp adapter_for_repo!(opts) do
    dynamic_expression_adapters =
      opts[:dynamic_expression_adapters] ||
        Config.dynamic_expression_adapters() ||
        @adapters

    repo = Config.repo!(opts)
    repo_adapter = repo.__adapter__()

    case Enum.find(dynamic_expression_adapters, fn {key, _} -> key === repo_adapter end) do
      {_, adapter} ->
        adapter

      _ ->
        raise ArgumentError,
              """
              Unable to determine a dynamic expression adapter for the given Ecto repo's adapter.

              Repo:
                #{inspect(repo)}

              Adapter:
                #{inspect(repo_adapter)}

              To fix this error, please provide the adapter configuration using one of the following approaches:

              1. Pass the adapter options at runtime via the `:dynamic_expression_adapters` key:

                  EctoShorts.Actions.all(MyApp.Post, %{published: true},
                    dynamic_expression_adapters: %{
                      Ecto.Adapters.Postgres => [adapter: EctoShorts.DynamicExpressions.Postgres]
                    }
                  )

              2. Configure the adapter in your application environment:

                  config :my_app, :dynamic_expression_adapters,
                    %{
                      Ecto.Adapters.Postgres => [adapter: EctoShorts.DynamicExpressions.Postgres]
                    }

              Without this configuration, EctoShorts cannot convert your parameters to an Ecto query.
              """
    end
  end
end
