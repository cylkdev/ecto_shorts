defmodule EctoShorts.CommonQueries.Reflection do
  alias Ecto.Queryable
  alias EctoShorts.SchemaHelpers

  @type from_expr :: %Ecto.Query.FromExpr{}
  @type join_expr :: %Ecto.Query.JoinExpr{}
  @type subquery :: Ecto.SubQuery.t()
  @type query :: Ecto.Query.t()
  @type schema :: Ecto.Queryable.t()
  @type source :: binary()
  @type expr_source :: source() | schema() | {source() | nil, schema() | nil}
  @type schema_input :: schema() | {source(), schema()}
  @type binding_alias :: atom() | nil
  @type key() :: atom()

  @doc """
  Converts the given `schema`, or `{source, schema}` to an `Ecto.Query` struct
  or returns an `Ecto.Query` struct as-is.

  ## Examples

      iex> EctoShorts.CommonQuery.to_query(EctoShorts.Schemas.Post)
      #Ecto.Query<from p0 in EctoShorts.Schemas.Post>

      iex> EctoShorts.CommonQuery.to_query({"custom_source", EctoShorts.Schemas.Post})
      #Ecto.Query<from p0 in {"custom_source", EctoShorts.Schemas.Post}>

      iex> import Ecto.Query
      ...> query = from p in EctoShorts.Schemas.Post
      ...> EctoShorts.CommonQuery.to_query(query)
      #Ecto.Query<from p0 in EctoShorts.Schemas.Post>
  """
  @spec to_query(query() | schema_input()) :: query()
  def to_query(source), do: Queryable.to_query(source)

  @doc """
  ...
  """
  def lookup_binding_expr_source(query, alias_or_position) do
    case lookup_binding_expr(query, alias_or_position) do
      %{on: _} = join_expr ->
        find_join_source(query, join_expr)

      %{source: _} = from_expr ->
        unwrap_expr_source(from_expr)

      value ->
        value
    end
  end

  defp find_join_source(%{from: from_expr} = _query, %{assoc: {0, key}} = _join_expr) do
    with {_, parent_schema} <- unwrap_expr_source(from_expr) do
      if parent_schema !== nil do
        {nil, SchemaHelpers.fetch_schema_assoc_module!(parent_schema, key)}
      end
    end
  end

  defp find_join_source(%{joins: joins} = query, %{assoc: {pos, key}} = join_expr) do
    case get_in(joins, [Access.at(pos)]) do
      nil ->
        if has_subquery?(query) do
          query
          |> get_inner_query()
          |> find_join_source(join_expr)
        end

      %{assoc: {^pos, ^key}} = _join_expr ->
        ref_join_expr = get_in(joins, [Access.at!(pos - 1)])

        with {_, parent_schema} <- find_join_source(query, ref_join_expr) do
          if parent_schema !== nil do
            {nil, SchemaHelpers.fetch_schema_assoc_module!(parent_schema, key)}
          end
        end
    end
  end

  defp find_join_source(_query, join_expr) do
    unwrap_expr_source(join_expr)
  end

  defp has_subquery?(%{from: %{source: %{query: _}}}), do: true
  defp has_subquery?(%{source: %{query: _}}), do: true
  defp has_subquery?(_), do: false

  defp get_inner_query(%{from: %{source: %{query: inner_query}}}), do: inner_query
  defp get_inner_query(%{query: query}), do: get_inner_query(query)
  defp get_inner_query(_), do: nil

  @doc """
  ...
  """
  def lookup_binding_expr(%_{} = query, pos) when is_integer(pos) do
    get_binding_by_index(query, pos)
  end

  def lookup_binding_expr(%_{} = query, binding_alias) do
    get_schema_binding(query, binding_alias)
  end

  def lookup_binding_expr(source, alias_or_position) do
    source
    |> to_query()
    |> lookup_binding_expr(alias_or_position)
  end

  defp get_binding_by_index(%_{from: from_expr} = _query, 0) do
    from_expr
  end

  defp get_binding_by_index(%_{joins: joins} = _query, pos) when pos < 0 do
    Enum.at(joins, pos)
  end

  defp get_binding_by_index(%_{joins: joins} = _query, pos) when pos > 0 do
    Enum.at(joins, pos - 1)
  end

  defp get_schema_binding(query, binding_alias) do
    with from_expr when is_struct(from_expr, Ecto.Query.FromExpr) <-
           find_binding_expr(query, binding_alias) do
      unwrap_expr(from_expr)
    end
  end

  defp find_binding_expr(%{from: from_expr, joins: joins} = query, binding_alias)
       when is_struct(query, Ecto.Query) do
    if is_nil(binding_alias) do
      unwrap_expr(from_expr)
    else
      with nil <- find_binding_expr(from_expr, binding_alias) do
        find_binding_expr(joins, binding_alias)
      end
    end
  end

  defp find_binding_expr(%{query: query} = _subquery, binding_alias) do
    find_binding_expr(query, binding_alias)
  end

  defp find_binding_expr(%{as: as, source: source} = join_expr, binding_alias)
       when is_struct(join_expr, Ecto.Query.JoinExpr) do
    if as === binding_alias do
      join_expr
    else
      find_binding_expr(source, binding_alias)
    end
  end

  defp find_binding_expr(%{as: as, source: source} = from_expr, binding_alias)
       when is_struct(from_expr, Ecto.Query.FromExpr) do
    if as === binding_alias do
      from_expr
    else
      find_binding_expr(source, binding_alias)
    end
  end

  defp find_binding_expr([], _), do: nil

  defp find_binding_expr([join_expr | joins], binding_alias) do
    with nil <- find_binding_expr(join_expr, binding_alias) do
      find_binding_expr(joins, binding_alias)
    end
  end

  defp find_binding_expr(_, _), do: nil

  defp unwrap_expr_source(expr) do
    unwrap_expr(expr).source
  end

  defp unwrap_expr(%{source: {_, _}} = expr), do: expr
  defp unwrap_expr(%{source: source}), do: unwrap_expr(source)
  defp unwrap_expr(%{query: query}), do: unwrap_expr(query)
  defp unwrap_expr(%{from: from_expr}), do: unwrap_expr(from_expr)
end
