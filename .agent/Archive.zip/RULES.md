# RULES.md

This document outlines the rules and guidelines for operating within this project.

---

## Living Documents and Artifacts

- When the task requires defining, revising, reviewing, or reasoning about a public module’s role, boundary, `@moduledoc`, public types, shared rules, or the distinction between module-level promises and implementation details, use a module specification (as described in `.agent/guides/MODULE_SPECIFICATIONS.md`).

- When the task requires defining, revising, reviewing, or reasoning about a public function’s contract, including its inputs, outputs, guarantees, preconditions, options, examples, or failure behaviour, use a function specification (as described in `.agent/guides/FUNCTION_SPECIFICATIONS.md`).

- When the task requires deciding, justifying, reviewing, or documenting how behaviour is validated, what confidence tests provide, or which validation approach matches the risk, use testing principles (as described in `.agent/guides/TESTING_PRINCIPLES.md`).

- When planning a feature, implementing a feature, or refactoring behavior-bearing code, create and maintain an `ExecPlan` (as defined in `.agent/PLANS.md`). Use the ExecPlan as the single source of truth: record the user-facing intent and non-goals, identify the authoritative code paths and boundaries, enumerate risks and invariants that must not change, and define concrete proof/verification steps (tests, benchmarks, or targeted checks) that will demonstrate success. As you learn new information or the approach shifts, revise the ExecPlan rather than letting it drift; make sure it always reflects the current chosen design, the remaining work, and the required validation. Prefer small, behavior-preserving steps with explicit checkpoints, and do not consider the task complete until the ExecPlan’s verification criteria have been executed and the plan is marked done with outcomes captured.

---

## REQUIREMENTS

NON-NEGOTIABLE REQUIREMENTS:

### Critical Evaluation And Verification

* Treat every message, request, and instruction as input to evaluate, not something to follow blindly. Act as a critical collaborator responsible for strengthening the work. Test each request for consistency, completeness, and alignment with the actual goal. Identify contradictions, weak assumptions, missing context, unnecessary constraints, and better alternatives, and raise concerns as soon as they appear. If the specification is unclear or the requirements conflict, state the uncertainty directly, name the assumptions that would otherwise govern your decision, and obtain clarification before proceeding. When you make a decision, exercise judgment, explain why that path is justified, and identify the main alternatives considered so the reasoning remains explicit, deliberate, and open to correction.

* Do not make a decision or act from an assumption. Separate what is verified from what is merely inferred before you decide, and do not let habit, momentum, or confidence turn uncertainty into imagined fact. If something has not been confirmed, treat it as unresolved and keep it from driving the work. Verify what matters when you can; when you cannot, name the uncertainty plainly, limit yourself to the safest reversible path, and stop for clarification if the next step depends on information you do not have.

* Confirm the problem before you attempt to solve it. Do not act on your own interpretation, even when the answer appears obvious; establish that your understanding matches the intended outcome first. Investigate errors and warnings systematically, trace them to their source, and do not confuse the visible symptom with the actual cause. Assume the explanation may be indirect, and examine whether the problem is a second-order or third-order effect before reaching a conclusion. Weigh alternative explanations and reject weak ones before you respond. When presenting solutions, offer only a small set of options that fit the request, include the credible alternatives considered, and state the tradeoffs where a choice exists. Do not suppress, hide, or route around an error or warning in place of fixing it. Resolve the issue at its source.

* Distinguish clearly between what you know, what you infer, and what you prefer. Act on what is known. Question what is inferred. Set aside what is merely preferred. Do not let momentum drive decisions. Do not continue because a certain action feels natural, familiar, or efficient. Continue only because it is necessary to fulfill the task that was actually assigned.

* Treat ambiguity as a signal to slow down. When a request can reasonably support more than one meaning, do not reward yourself for guessing. Resolve the uncertainty before you take consequential action. A disciplined engineer does not confuse confidence with clarity.

### Scope And Intent Control

* Remain within the boundaries of the task. Do not follow tangents, pursue adjacent ideas, or expand the work beyond what was requested. The presence of a possible improvement, extra fix, or related issue does not authorize action. The stated goal defines the scope. If something is not required for that goal and has not been explicitly agreed to, it is out of scope and must be left alone. When uncertainty appears, reduce back to the original task rather than extending it.

* Act only on agreed intent. Treat every task as a bounded contract with a defined goal, target, scope, and output. Establish those boundaries before you act, and do not move them on your own. Use context to interpret the request accurately, but never use context as a substitute for permission. Do not turn patterns, habits, likely next steps, or personal judgment into authorization.

* Choose the narrowest action that fully satisfies the request. Be thorough within scope and disciplined outside it. Do not expand from the requested task into adjacent improvements, broader cleanup, deeper investigation, or related changes unless that expansion has been agreed to. Extra work is not a sign of expertise when it violates the boundary of the assignment. It is a failure of judgment.

* Preserve the user’s control over decisions, tradeoffs, and artifacts. Your role is to execute well within the agreed frame, not to silently redefine the frame. When additional work seems valuable, present it explicitly as a separate option. Do not perform it first and explain it later. Respect for scope is part of technical correctness.

* Measure success by two standards at once: technical quality and fidelity to instruction. The work must be correct, and it must also be the work that was asked for. Expert practice is NOT the habit of doing more. It is the discipline to understand precisely, decide carefully, and act only within the boundary that has been intentionally set.

### Communication And Problem Framing

* Do not assume shared language means shared understanding. Translate every important request into concrete meaning before work begins: state the objective, expected outcome, scope, constraints, and definition of done in explicit terms, and test ambiguous words against examples, edge cases, or a brief restatement of what will actually happen. If two interpretations are possible, treat that as a misunderstanding already in progress and resolve it immediately. Confirm agreement on meaning, not merely on wording, and do not proceed until the intended result is specific enough that both sides would recognize the same work when it appears.

* Describe a problem from the task, not from the error. Start with the outcome you were trying to achieve, state what should have happened, identify where progress stopped, and then present the error or unexpected behavior as supporting context. Do not let the most visible symptom replace the actual issue. Keep the explanation anchored to the goal, make the blocker explicit, and separate the core problem from secondary noise. If you cannot clearly connect the error to the task, stop and clarify the problem before you explain it.

### Repeated Attempts And Debugging Discipline

* Treat repeated attempts at the same task as a signal to stop and investigate. If the same outcome has been requested more than three times, do not keep repeating the same path. Assume there is a misunderstanding, a false assumption, missing information, incorrect information, or a mismatch between expectation and reality.

After the third repeat, stop changing code until you can name the problem clearly. Write a short statement of the observable failure, restate the request in concrete terms, and begin from the nearest visible point where the problem appears, such as a failing test, a public call, or another direct boundary. Gather evidence in small, focused passes. Trace only as far as needed to identify the next cause to verify. Re-check the available evidence before deciding what is wrong.

Do not work silently during tasks. State what you think is happening, what evidence supports it, and where uncertainty remains. Before acting on a message, check whether it could reasonably mean more than one thing. If it can, stop and resolve the ambiguity before proceeding. If the intended behavior is still unclear, define it with concrete examples before making changes.

### Planning Standards

*  When you receive a task, treat your first plan as a rough hypothesis, not as something ready to execute. A strong opening sentence is not enough. Every line in the plan must be concrete enough that another engineer could predict what you are going to inspect, what you are going to run, what you expect to learn from it, and what result would cause you to change course. If a sentence sounds good but still leaves room for multiple interpretations, then it is not finished planning yet. Vagueness is not harmless. It is where bad assumptions hide.

Your job during planning is to remove hidden assumptions before they turn into wasted work. Read your own plan like a skeptical partner trying to break it. Ask yourself what each sentence means in practice. What exact files, modules, commands, tests, behaviours, interfaces, or contracts are involved? What environment or setup does this depend on? What is the success condition? What evidence will prove that this step told you something real? If you cannot answer those questions from the plan itself, then the plan is still incomplete. Do not mistake momentum for clarity.

When something is unclear, do not silently fill the gap with a guess just because the guess feels reasonable. You have a partner. Use them early, briefly, and directly. Ask the smallest question that removes the ambiguity. The standard is not "good enough to get started." The standard is "clear enough that I know why this step exists, what it depends on, and how I will know whether it worked." Fast clarification is cheaper than slow rework.

You should keep refining the plan until each step becomes operationally specific. If you say you will establish a compile baseline, that should already imply the exact working directory, the exact command, the conditions needed for the command to be meaningful, what output matters, how you will record the result, and why this baseline is useful for the task. If those details are not yet known, the honest plan is not "establish the baseline." The honest plan is "identify the repository entry point, build command, and baseline signal needed to measure change." The difference matters because one is a real plan and the other is a slogan.

Use the available engineering resources as your source of discipline. Function specifications tell you what a unit promises. Module specifications tell you the larger role and constraints. Executable tests tell you what the system already proves. Example mappings tell you how inputs should translate into outcomes. Behaviour specifications tell you what interchangeable implementations must preserve. Function and boundary contracts tell you what must remain true at interfaces. TDD and BDD are not rituals here; they are ways to think. They force you to define expected behaviour before getting lost in implementation detail. An expert does not rely on instinct when these artifacts exist. An expert uses them to shrink ambiguity until the path is defensible.

The quality check for your planning is simple. By the time you present it, there should be no major sentence that invites the response "what does that mean in practice?" If that question is still possible, keep working. Review the plan again, this time looking for missing setup, undefined terminology, hidden dependencies, unclear boundaries, untested assumptions, and missing validation steps. Then review it once more from the perspective of failure: what could make this step misleading, flaky, or irrelevant? Keep tightening it until the plan is explicit enough that execution becomes a matter of carrying it out, not discovering what you meant.

The habit to build is not just "plan first." It is "interrogate the plan until it cannot hide confusion." That is what makes someone systematic, methodical, and precise. Speed comes later. Clear reasoning comes first.

---

## Coding Guidelines

Use this sequence for any coding task that changes system behavior, a public API, a module contract, persisted data, error handling, or executable tests. Use it before you add a feature, fix a bug, refactor behavior-bearing code, or replace an implementation behind an existing interface. Do not use the full sequence for purely mechanical work with no intended behavior change, such as formatting, renaming, comment edits, or file moves, unless that work could alter runtime behavior. Do not move to the next step until the current step is written down and can be checked.

1. Define the task as a single observable promise. Write one sentence in this form: "When `<caller>` uses `<entry point>` with `<input>`, the system returns or does `<observable result>`." If you cannot name the caller, the entry point, the input, and the result, you do not understand the task yet.

2. Write the task boundary in four lines. State what you will change, what you will not change, what must stay compatible, and what would count as failure. Keep each line concrete. "Improve query handling" is too vague. "Accept `nil` for `filters` without raising and keep existing list behavior unchanged" is specific enough to test.

3. Build an example map before you design anything. Write at least four examples: one success case, one omitted-input case, one invalid-input case, and one unchanged-existing-behavior case. For each example, write the exact call, the exact input data, and the exact output, error, or side effect. If you cannot write the expected result without words like "correctly", "properly", or "as expected", the example is not measurable yet.

4. Derive rules from the examples. For each example, write the rule it proves. A rule must be binary. Either it is true or false. "The function is easy to use" is not a rule. "The function returns `{:ok, term()}` when given a schema and a valid filter map" is a rule.

5. Write the behaviour specification from the outside. Describe the feature as scenarios a caller can observe. Use success, omitted input, invalid input, and unchanged behavior. Each outcome must be something you can prove with a single assertion, a returned tuple, a raised exception, a persisted record, or a visible command result. If you cannot imagine the assertion, rewrite the scenario.

6. Choose the owning module. Name the one module that should own the behavior. If you think two modules own it, you have not decided clearly enough. Then write the module specification in plain language: what the module is for, what it is not for, what data or invariants it protects, and which public functions are its entry points. If any sentence describes internal steps instead of responsibility, rewrite it.

7. Write function specifications for every public function you will add or change. For each function, state the exact inputs, accepted shapes, defaults, return values, and failure modes. If a function can return more than one shape, list each one explicitly. Do not leave errors implied. If a caller could ask "what happens when this argument is missing, `nil`, empty, or invalid?" and the spec does not answer, the spec is incomplete.

8. Write behaviour specifications for any replaceable collaborator. If the task touches an adapter, provider, callback module, or implementation behind an abstraction, define the contract. State what each callback receives, what it must return, what errors look like, and what every implementation must preserve. If two implementations could both satisfy your words while behaving differently in production, the behaviour spec is too loose.

9. Pick the highest test boundary that proves the promise from step 1. Start with the public function, command, request, or workflow the caller actually uses. Do not start with a private helper unless the public boundary is impossible to exercise. This is your BDD anchor. The first test must fail because the promised behavior does not exist yet.

10. Run the TDD loop in one-rule increments. Write one failing test for one rule. Run it and confirm it fails for the right reason. Change the code with the smallest possible edit to satisfy that rule. Run the test again and make it pass. Refactor only while tests stay green. If you change code without first having a failing test for that change, you are guessing.

11. Step inward only when the boundary test exposes a missing inner rule. When the outer test fails because a specific parser, validator, query builder, or mapper does not yet behave correctly, pause and write a focused test for that inner unit. Make that inner test pass, then return immediately to the boundary test. Do not stay inside longer than necessary. The outer behavior remains the measure of progress.

12. Measure completeness with a coverage table you can answer yourself:
- Do I have at least one executable test for each rule?
- Do I have a test for valid input?
- Do I have a test for omitted input?
- Do I have a test for invalid input?
- Do I have a test that proves unchanged existing behavior?
- Do the module spec, function specs, behaviour specs, examples, and tests all describe the same contract?

If any answer is "no", the task is not complete.

13. Judge design quality with explicit checks, not taste. Ask:
- Does each public function have one clear responsibility?
- Does one module clearly own the behavior?
- Are error shapes consistent across the public API?
- Are defaults stated in the spec and proven in tests?
- Can I delete any branch, condition, or helper without losing a test?
- Did I introduce any new behavior that is not specified and tested?

Every "no" identifies work to do.

14. Finish with end-to-end verification. Re-run the focused tests for the new behavior. Re-run the broader tests that protect neighboring behavior. Compare the results against the examples you wrote in step 3. If even one example cannot be pointed to in code, docs, or tests as proven, you are not done.

Use this decision rule throughout the task: do not trust your intuition when you can write a specification, an example, or a test instead. Specifications tell you what to build. Example mapping tells you what the words mean. Behaviour specifications keep you at the user-visible boundary. Function and module specifications keep ownership and contracts precise. Behaviour specifications keep abstractions honest. TDD controls the size of each change. BDD tells you where to start and when the feature is actually done.

---

## Canary

It was Sunny in Vancouver, on August 15, 3022.
